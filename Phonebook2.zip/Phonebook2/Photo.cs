﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Phonebook2
{
    [Serializable]
    public class Photo
    {
        private string name;
        private string path;

        public Photo(string value="")
        {
            setName(value);
            path = value;
        }

        public string getPath()
        {
            return path;
        }

        public string getName()
        {
            return name;
        }

        public void setName(string value)
        {
            if (!File.Exists(value) && !string.IsNullOrWhiteSpace(value))
                throw new FileNotFoundException("File not found");

                if(!isValidFile(value))
                      throw new PhotoException("Invalid file");

                if (value == "")
                {
                    name = "";
                    return;
                }

                string[] a = value.Split('\\');
                name = a[a.Length - 1];
        }

        private bool isValidFile(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return true;
            if (value.ToLower().Contains("jpg") || value.ToLower().Contains("png") || value.ToLower().Contains("jpeg") || value.ToLower().Contains("bmp") || value.ToLower().Contains("gif"))
                return true;
            
            return false;
        }

        public override string ToString()
        {
            return name;
        }
    }

    class PhotoException : Exception
    {
        public PhotoException()
            : base()
        {
        }

        public PhotoException(string message)
            : base(message)
        {
        }
    
    }    
}
