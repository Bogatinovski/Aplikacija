﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;

namespace Phonebook2
{
    public enum Sex
    {
        Female, Male, Other
    }

    public enum Category
    {
        Acquaintance, Colegue, Family, Friend
    }

    public class Contact
    {
        public  const string MALE_PHOTO = "photos\\male.png";
        public const string FEMALE_PHOTO = "photos\\female.png";
        public const string OTHER_PHOTO = "photos\\other.png";

        List<Number> numbers;
        List<Email> emails;
        DateTime birthday;

        List<Address> addresses;
        string city;
        string country;
        string name;
        string company;
        string zipCode;
        Category category;
        Sex sex;
        
        public string fileName;
        public int index;
        
        private const short maxLength = 40;

        public Contact(List<Number> num, List<Email> em, DateTime birth, List<Address> adr, string city = "", string country="", string company="", string name="", string zip="", Sex sex=Sex.Male, Category category = Category.Friend)
        {
            numbers = num;
            emails = em;
            birthday = birth;
            addresses = adr;
            this.sex = sex;
            setCity(city);
            setCountry(country);
            setCompany(company);
            setName(name);
            setZipCode(zip);
            setCategory(category);
        }
        public Contact()
        {
            numbers = new List<Number>();
            emails = new List<Email>();
            birthday = new DateTime(1,1,1);
            addresses = new List<Address>();
        }


        #region Getters and Setters
        public string getPhotoPath()
        {
            if (sex == Sex.Male)
                return MALE_PHOTO;
            else return FEMALE_PHOTO;
        }
        public Category getCategory()
        {
            return this.category;
        }
        public List<Number> getNumber()
        {
            return numbers;
        }
        public List<Email> getEmail()
        {
            return emails;
        }
        public List<Address> getAdress()
        {
            return addresses;
        }
        public DateTime getBirthday()
        {
            return birthday;
        }
        public string getCity()
        {
            return city;
        }
        public string getCountry()
        {
            return country;
        }
        public string getZipCode()
        {
            return zipCode;
        }
        public string getName()
        {
            return name;
        }
        public string getCompany()
        {
            return company;
        }
        public Sex getSex()
        {
            return this.sex;
        }


        public void setBirthday(DateTime b)
        {
            birthday = b;
        }
        public void setNumbers(List<Number> n)
        {
            numbers = n;
        }
        public void setEmail(List<Email> e)
        {
            emails = e;
        }
        public void setCategory(Category value)
        {
            this.category = value;
        }
        public void setAddress(List<Address> value)
        {
            addresses = value;
        }
        public void setCity(string value)
        {
            if (value.Length > maxLength)
                throw new StringTooLongException("City name is too long");
            city = value;
        }
        public void setCountry(string value)
        {
            if (value.Length > maxLength)
                throw new StringTooLongException("Country name is too long");
            country = value;
        }
        public void setName(string value)
        {
            if (value.Length > maxLength)
                throw new StringTooLongException("Contact name is too long");
            name = value;
        }
        public void setCompany(string value)
        {
            if (value.Length > maxLength)
                throw new StringTooLongException("Company name is too long");
            company = value;
        }
        public void setZipCode(string value)
        {
            foreach (char c in value)
                if (!Char.IsDigit(c))
                    throw new InvalidZipCodeException("Invalid zip code format");
            zipCode = value;
        }
        public void setSex(Sex value)
        {
            this.sex = value;
        }

        #endregion

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(name);
            if(!String.IsNullOrEmpty(city.Trim()))
                sb.AppendLine(city);
            if (!String.IsNullOrEmpty(zipCode.Trim()))
                sb.AppendLine(zipCode);
            if (!String.IsNullOrEmpty(country.Trim()))
                sb.AppendLine(country);
            if (!String.IsNullOrEmpty(company.Trim()))
                sb.AppendLine(company);
            if (!String.IsNullOrEmpty(birthday.ToString()))
                sb.AppendLine(birthday.ToString("dd.mm.yyyy"));
            sb.AppendLine(sex.ToString());
            sb.AppendLine(category.ToString());
            foreach (Number num in numbers)
                sb.AppendLine(num.ToString());
            foreach (Address addr in addresses)
                sb.AppendLine(addr.ToString());
            foreach (Email email in emails)
                sb.AppendLine(email.ToString());

            return sb.ToString();
        }
        
        public void LoadContactFromFile(String path)
        {
            this.fileName = path;
            XmlDocument document = new XmlDocument();
            document.Load(path);

            XmlNode contactNode = document.SelectSingleNode("Contact");
            name = contactNode["Name"].Attributes["Value"].Value;
            city = contactNode["City"].Attributes["Value"].Value;
            zipCode = contactNode["ZipCode"].Attributes["Value"].Value;
            country = contactNode["Country"].Attributes["Value"].Value;
            company = contactNode["Company"].Attributes["Value"].Value;
            string day, month, year;
            day = contactNode["Birthday"].Attributes["Day"].Value;
            month = contactNode["Birthday"].Attributes["Month"].Value;
            year = contactNode["Birthday"].Attributes["Year"].Value;     
            birthday = new DateTime(Int32.Parse(year), Int32.Parse(month), Int32.Parse(day));
            sex = (Sex)Int32.Parse(contactNode["Sex"].Attributes["Value"].Value);
            category = (Category)Int32.Parse(contactNode["Category"].Attributes["Value"].Value);

            foreach(XmlNode emailNode in contactNode["Emails"].SelectNodes("Email"))
                emails.Add(new Email(emailNode.Attributes["Value"].Value));

            foreach (XmlNode numberNode in contactNode["Numbers"].SelectNodes("Number"))
                numbers.Add(new Number(numberNode.Attributes["Value"].Value,
                    (NumberType)Int32.Parse(numberNode.Attributes["PhoneType"].Value)));

            foreach (XmlNode addressNode in contactNode["Addresses"].SelectNodes("Address"))
                addresses.Add(new Address(addressNode.Attributes["Value"].Value,
                    (AddressType)Int32.Parse(addressNode.Attributes["AddressType"].Value)));
         
        }

        public void SaveContactToFile()
        {
            XmlDocument document = new XmlDocument();
            XmlElement contact = document.CreateElement("Contact");
            XmlAttribute attribute;

            document.AppendChild(contact);

            //// Name
            XmlElement nameElement = document.CreateElement("Name");
            attribute = document.CreateAttribute("Value");
            attribute.Value = name;
            nameElement.Attributes.Append(attribute);
            contact.AppendChild(nameElement);

            //// City
            XmlElement cityElement = document.CreateElement("City");
            attribute = document.CreateAttribute("Value");
            attribute.Value = city;
            cityElement.Attributes.Append(attribute);
            contact.AppendChild(cityElement);

            //// Zip Code
            XmlElement zipCodeElement = document.CreateElement("ZipCode");
            attribute = document.CreateAttribute("Value");
            attribute.Value = zipCode;
            zipCodeElement.Attributes.Append(attribute);
            contact.AppendChild(zipCodeElement);

            //// Country
            XmlElement countryElement = document.CreateElement("Country");
            attribute = document.CreateAttribute("Value");
            attribute.Value = country;
            countryElement.Attributes.Append(attribute);
            contact.AppendChild(countryElement);

            //// Company
            XmlElement companyElement = document.CreateElement("Company");
            attribute = document.CreateAttribute("Value");
            attribute.Value = company;
            companyElement.Attributes.Append(attribute);
            contact.AppendChild(companyElement);

            //// Birthday
            XmlElement birthdayElement = document.CreateElement("Birthday");
            attribute = document.CreateAttribute("Day");
            attribute.Value = birthday.Day.ToString();
            birthdayElement.Attributes.Append(attribute);
            attribute = document.CreateAttribute("Month");
            attribute.Value = birthday.Month.ToString();
            birthdayElement.Attributes.Append(attribute);
            attribute = document.CreateAttribute("Year");
            attribute.Value = birthday.Year.ToString();
            birthdayElement.Attributes.Append(attribute);
            contact.AppendChild(birthdayElement);

            //// Sex
            XmlElement sexElement = document.CreateElement("Sex");
            attribute = document.CreateAttribute("Value");
            attribute.Value = ((int)sex).ToString();
            sexElement.Attributes.Append(attribute);
            contact.AppendChild(sexElement);

            /// Category 
            XmlElement categoryElement = document.CreateElement("Category");
            attribute = document.CreateAttribute("Value");
            attribute.Value = ((int)category).ToString();
            categoryElement.Attributes.Append(attribute);
            contact.AppendChild(categoryElement);

            /// Emails
            XmlElement emailsElement = document.CreateElement("Emails");

            foreach(Email email in emails)
            {
                XmlElement emailElement = document.CreateElement("Email");
                attribute = document.CreateAttribute("Value");
                attribute.Value = email.getEmailAdress();
                emailElement.Attributes.Append(attribute);
                emailsElement.AppendChild(emailElement);
            }

            contact.AppendChild(emailsElement);

            /// Numbers
            XmlElement numbersElement = document.CreateElement("Numbers");

            foreach (Number number in numbers)
            {
                XmlElement numberElement = document.CreateElement("Number");
                attribute = document.CreateAttribute("Value");
                attribute.Value = number.getNumber();
                numberElement.Attributes.Append(attribute);
                attribute = document.CreateAttribute("PhoneType");
                attribute.Value = ((int)number.phoneType).ToString();
                numberElement.Attributes.Append(attribute);
                numbersElement.AppendChild(numberElement);
            }

            contact.AppendChild(numbersElement);

            /// Addresses
            XmlElement addressesElement = document.CreateElement("Addresses");

            foreach (Address address in addresses)
            {
                XmlElement addressElement = document.CreateElement("Address");
                attribute = document.CreateAttribute("Value");
                attribute.Value = address.getAddress();
                addressElement.Attributes.Append(attribute);
                attribute = document.CreateAttribute("AddressType");
                attribute.Value = ((int)address.getAddressType()).ToString();
                addressElement.Attributes.Append(attribute);
                addressesElement.AppendChild(addressElement);
            }

            contact.AppendChild(addressesElement);

            document.Save(fileName);
        }
    }



    class StringTooLongException : Exception
    {
        public StringTooLongException()
            : base()
        {
        }

        public StringTooLongException(string message)
            : base(message)
        {
        }
    }
    
    class InvalidZipCodeException : Exception
    {
        public InvalidZipCodeException()
            : base()
        {
        }

        public InvalidZipCodeException(string message)
            : base(message)
        {
        }
    }

}
