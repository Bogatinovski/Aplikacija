﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;


namespace Phonebook2
{
    public class Number
    {
        private string number;
        public NumberType phoneType;

        public Number(string number, NumberType type = NumberType.Home)
        {
            setNumber(number);
            phoneType = type;
        }
        public Number()
        {

        }


        public string getNumber()
        {
            return number;
        }

        public void setNumber(string value)
        {
            number = value;
        }


        public override string ToString()
        {
            return String.Format("{0}-{1}", number,phoneType.ToString());
        }

    }

    public enum NumberType
    {
        Home,
        Mobile,
        Work
    }
}
