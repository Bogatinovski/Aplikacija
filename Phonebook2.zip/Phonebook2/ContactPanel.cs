﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Phonebook2
{
    public class ContactPanel
    {

        public const int panelWidth = 210;
        Contact contact;
        Form1 form;
        Panel panel;
        Label label;
        PictureBox picture;
        public Point location;
        Control parent;

        public ContactPanel(Contact c, Form1 form, Point location, Control parent)
        {
            this.contact = c;
            this.form = form;
            this.location = location;
            this.parent = parent;
            InitializePanel();
            InitializePicutre();
            InitializeLabel();
            panel.Click += new EventHandler(Panel_Click);
            label.Click += new EventHandler(Panel_Click);
            picture.Click += new EventHandler(Panel_Click);
        }

        private void Panel_Click(object sender, EventArgs e)
        {
            form.ShowContactInfo(contact);
        }

        public void Dispose()
        {
            panel.Controls.Remove(label);
            panel.Controls.Remove(picture);
            parent.Controls.Remove(panel);
        }

        private void InitializePanel()
        {
            panel = new Panel();
            panel.Size = new Size(210, 60);
            panel.Cursor = Cursors.Hand;
            panel.Location = location;
            panel.BorderStyle = BorderStyle.FixedSingle;
            parent.Controls.Add(panel);
        }

        private void InitializePicutre()
        {
            picture = new PictureBox();
            picture.Size = new Size(60, 60);
           // picutre.BorderStyle = BorderStyle.Fixed3D;
            picture.BackgroundImageLayout = ImageLayout.Stretch;
            string imgPath;
            if (contact.getSex() == Sex.Male)
                imgPath = Contact.MALE_PHOTO;
            else if (contact.getSex() == Sex.Female)
                imgPath = Contact.FEMALE_PHOTO;
            else imgPath = Contact.OTHER_PHOTO;

            Image image = Image.FromFile(imgPath);
            picture.BackgroundImage = image;
            panel.Controls.Add(picture);
        }

        private void InitializeLabel()
        {
            label = new Label();
            label.Font = new Font("Century Gothic", 10, FontStyle.Bold);
            label.ForeColor = Color.FromName("PowderBlue");
            label.Text = contact.getName();
            label.MinimumSize = new Size(140, 10);
            label.Location = new Point(picture.Size.Width, 0);
            panel.Controls.Add(label);
        }

        public Contact getContact()
        {
            return this.contact;
        }

        public void DisableContactPanel()
        {
            panel.Click -= Panel_Click;
            label.Click -= Panel_Click;
            picture.Click -= Panel_Click;
            panel.Cursor = Cursors.Default;
        }
    

        public void EnableContactPanel()
        {
            panel.Click += new EventHandler(Panel_Click);
            label.Click += new EventHandler(Panel_Click);
            picture.Click += new EventHandler(Panel_Click);
            panel.Cursor = Cursors.Hand;
        }

        public Control getParent()
        {
            return this.parent;
        }
    }
}
