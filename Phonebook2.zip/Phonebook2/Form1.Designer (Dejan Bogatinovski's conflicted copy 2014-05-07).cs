﻿namespace Phonebook2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.categoryLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ZiptextBox2 = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.cityLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.nameTextBox1 = new System.Windows.Forms.TextBox();
            this.CountrytextBox7 = new System.Windows.Forms.TextBox();
            this.companyLabel = new System.Windows.Forms.Label();
            this.CitytextBox5 = new System.Windows.Forms.TextBox();
            this.CompanytextBox9 = new System.Windows.Forms.TextBox();
            this.zipLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.contryLabel = new System.Windows.Forms.Label();
            this.comboBoxDays = new System.Windows.Forms.ComboBox();
            this.comboBoxMonths = new System.Windows.Forms.ComboBox();
            this.comboBoxYears = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.emailLabel = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.adressLabel = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.numberLabel = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.num2TextBox12 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.panelView = new System.Windows.Forms.Panel();
            this.daysView = new System.Windows.Forms.TextBox();
            this.monthsView = new System.Windows.Forms.TextBox();
            this.yearsView = new System.Windows.Forms.TextBox();
            this.sexView = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.addressView = new System.Windows.Forms.ComboBox();
            this.emailView = new System.Windows.Forms.ComboBox();
            this.numberView = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.zipCodeView = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.nameView = new System.Windows.Forms.TextBox();
            this.countryView = new System.Windows.Forms.TextBox();
            this.cityView = new System.Windows.Forms.TextBox();
            this.companyView = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.backFromViewBtn = new System.Windows.Forms.Button();
            this.changeViewBtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.btnChangeInfoOwner = new System.Windows.Forms.Button();
            this.defaultImg = new System.Windows.Forms.Button();
            this.changeImageBtn = new System.Windows.Forms.Button();
            this.panelImgOwner = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.profesionOwner = new System.Windows.Forms.TextBox();
            this.nameEduOwner = new System.Windows.Forms.TextBox();
            this.levelOwner = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.workNumOwner = new System.Windows.Forms.TextBox();
            this.addressCompanyOwner = new System.Windows.Forms.TextBox();
            this.positionOwner = new System.Windows.Forms.TextBox();
            this.companyOwner = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.numberOwner = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.listEmailOwner = new System.Windows.Forms.ComboBox();
            this.listNumberOwner = new System.Windows.Forms.ComboBox();
            this.yearOwner = new System.Windows.Forms.ComboBox();
            this.monthOwner = new System.Windows.Forms.ComboBox();
            this.dayOwner = new System.Windows.Forms.ComboBox();
            this.emailOwner = new System.Windows.Forms.TextBox();
            this.addressOwner = new System.Windows.Forms.TextBox();
            this.nameOwner = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.filesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolbarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.onToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.offToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.contactsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewContactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewAllContactsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.profileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seeYourInformationsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homePanel = new System.Windows.Forms.FlowLayoutPanel();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.friendsMoreLabel = new System.Windows.Forms.LinkLabel();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.familyMoreLabel = new System.Windows.Forms.LinkLabel();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.colegueMoreLabel = new System.Windows.Forms.LinkLabel();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.acquaintanceMoreLabel = new System.Windows.Forms.LinkLabel();
            this.moreContactsPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.label35 = new System.Windows.Forms.Label();
            this.searchTextBox = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panelView.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.homePanel.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.moreContactsPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 29);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(444, 599);
            this.panel1.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.IndianRed;
            this.label3.Location = new System.Drawing.Point(38, 565);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 20);
            this.label3.TabIndex = 44;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBox2);
            this.groupBox4.Controls.Add(this.categoryLabel);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label8);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.ZiptextBox2);
            this.groupBox4.Controls.Add(this.nameLabel);
            this.groupBox4.Controls.Add(this.cityLabel);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.comboBox5);
            this.groupBox4.Controls.Add(this.nameTextBox1);
            this.groupBox4.Controls.Add(this.CountrytextBox7);
            this.groupBox4.Controls.Add(this.companyLabel);
            this.groupBox4.Controls.Add(this.CitytextBox5);
            this.groupBox4.Controls.Add(this.CompanytextBox9);
            this.groupBox4.Controls.Add(this.zipLabel);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.label10);
            this.groupBox4.Controls.Add(this.contryLabel);
            this.groupBox4.Controls.Add(this.comboBoxDays);
            this.groupBox4.Controls.Add(this.comboBoxMonths);
            this.groupBox4.Controls.Add(this.comboBoxYears);
            this.groupBox4.Controls.Add(this.label11);
            this.groupBox4.Location = new System.Drawing.Point(30, 10);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(379, 257);
            this.groupBox4.TabIndex = 43;
            this.groupBox4.TabStop = false;
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Acquaintance",
            "Colegue",
            "Family",
            "Friend"});
            this.comboBox2.Location = new System.Drawing.Point(126, 224);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(144, 24);
            this.comboBox2.Sorted = true;
            this.comboBox2.TabIndex = 41;
            // 
            // categoryLabel
            // 
            this.categoryLabel.AutoSize = true;
            this.categoryLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.categoryLabel.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.categoryLabel.ForeColor = System.Drawing.Color.Teal;
            this.categoryLabel.Location = new System.Drawing.Point(13, 224);
            this.categoryLabel.MaximumSize = new System.Drawing.Size(100, 25);
            this.categoryLabel.MinimumSize = new System.Drawing.Size(100, 23);
            this.categoryLabel.Name = "categoryLabel";
            this.categoryLabel.Size = new System.Drawing.Size(100, 23);
            this.categoryLabel.TabIndex = 40;
            this.categoryLabel.Text = "Category";
            this.categoryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label7.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Teal;
            this.label7.Location = new System.Drawing.Point(14, 50);
            this.label7.MaximumSize = new System.Drawing.Size(100, 25);
            this.label7.MinimumSize = new System.Drawing.Size(100, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(100, 23);
            this.label7.TabIndex = 16;
            this.label7.Text = "City";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label8.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Teal;
            this.label8.Location = new System.Drawing.Point(13, 79);
            this.label8.MaximumSize = new System.Drawing.Size(100, 25);
            this.label8.MinimumSize = new System.Drawing.Size(100, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 23);
            this.label8.TabIndex = 17;
            this.label8.Text = "Zip Code";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label6.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Teal;
            this.label6.Location = new System.Drawing.Point(14, 108);
            this.label6.MaximumSize = new System.Drawing.Size(100, 25);
            this.label6.MinimumSize = new System.Drawing.Size(100, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 23);
            this.label6.TabIndex = 15;
            this.label6.Text = "Country";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ZiptextBox2
            // 
            this.ZiptextBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ZiptextBox2.Location = new System.Drawing.Point(127, 80);
            this.ZiptextBox2.MaxLength = 0;
            this.ZiptextBox2.Name = "ZiptextBox2";
            this.ZiptextBox2.Size = new System.Drawing.Size(197, 22);
            this.ZiptextBox2.TabIndex = 8;
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.BackColor = System.Drawing.Color.Transparent;
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.ForeColor = System.Drawing.Color.Firebrick;
            this.nameLabel.Location = new System.Drawing.Point(340, 24);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(13, 15);
            this.nameLabel.TabIndex = 30;
            this.nameLabel.Text = "*";
            this.nameLabel.Visible = false;
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.BackColor = System.Drawing.Color.Transparent;
            this.cityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityLabel.ForeColor = System.Drawing.Color.Firebrick;
            this.cityLabel.Location = new System.Drawing.Point(340, 59);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(13, 15);
            this.cityLabel.TabIndex = 36;
            this.cityLabel.Text = "*";
            this.cityLabel.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Teal;
            this.label1.Location = new System.Drawing.Point(14, 21);
            this.label1.MaximumSize = new System.Drawing.Size(100, 25);
            this.label1.MinimumSize = new System.Drawing.Size(100, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 10;
            this.label1.Text = "Name *";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Female",
            "Male",
            "Other"});
            this.comboBox5.Location = new System.Drawing.Point(126, 195);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(144, 24);
            this.comboBox5.Sorted = true;
            this.comboBox5.TabIndex = 39;
            // 
            // nameTextBox1
            // 
            this.nameTextBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameTextBox1.Location = new System.Drawing.Point(127, 22);
            this.nameTextBox1.MaxLength = 18;
            this.nameTextBox1.Name = "nameTextBox1";
            this.nameTextBox1.Size = new System.Drawing.Size(197, 22);
            this.nameTextBox1.TabIndex = 0;
            // 
            // CountrytextBox7
            // 
            this.CountrytextBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CountrytextBox7.Location = new System.Drawing.Point(127, 109);
            this.CountrytextBox7.MaxLength = 40;
            this.CountrytextBox7.Name = "CountrytextBox7";
            this.CountrytextBox7.Size = new System.Drawing.Size(197, 22);
            this.CountrytextBox7.TabIndex = 6;
            // 
            // companyLabel
            // 
            this.companyLabel.AutoSize = true;
            this.companyLabel.BackColor = System.Drawing.Color.Transparent;
            this.companyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.companyLabel.ForeColor = System.Drawing.Color.Firebrick;
            this.companyLabel.Location = new System.Drawing.Point(339, 141);
            this.companyLabel.Name = "companyLabel";
            this.companyLabel.Size = new System.Drawing.Size(13, 15);
            this.companyLabel.TabIndex = 38;
            this.companyLabel.Text = "*";
            this.companyLabel.Visible = false;
            // 
            // CitytextBox5
            // 
            this.CitytextBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CitytextBox5.Location = new System.Drawing.Point(127, 51);
            this.CitytextBox5.MaxLength = 40;
            this.CitytextBox5.Name = "CitytextBox5";
            this.CitytextBox5.Size = new System.Drawing.Size(197, 22);
            this.CitytextBox5.TabIndex = 7;
            // 
            // CompanytextBox9
            // 
            this.CompanytextBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CompanytextBox9.Location = new System.Drawing.Point(126, 138);
            this.CompanytextBox9.MaxLength = 40;
            this.CompanytextBox9.Name = "CompanytextBox9";
            this.CompanytextBox9.Size = new System.Drawing.Size(197, 22);
            this.CompanytextBox9.TabIndex = 9;
            // 
            // zipLabel
            // 
            this.zipLabel.AutoSize = true;
            this.zipLabel.BackColor = System.Drawing.Color.Transparent;
            this.zipLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zipLabel.ForeColor = System.Drawing.Color.Firebrick;
            this.zipLabel.Location = new System.Drawing.Point(340, 87);
            this.zipLabel.Name = "zipLabel";
            this.zipLabel.Size = new System.Drawing.Size(13, 15);
            this.zipLabel.TabIndex = 37;
            this.zipLabel.Text = "*";
            this.zipLabel.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label9.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Teal;
            this.label9.Location = new System.Drawing.Point(13, 137);
            this.label9.MaximumSize = new System.Drawing.Size(100, 25);
            this.label9.MinimumSize = new System.Drawing.Size(100, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(100, 23);
            this.label9.TabIndex = 18;
            this.label9.Text = "Company";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label10.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Teal;
            this.label10.Location = new System.Drawing.Point(13, 166);
            this.label10.MaximumSize = new System.Drawing.Size(100, 25);
            this.label10.MinimumSize = new System.Drawing.Size(100, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 23);
            this.label10.TabIndex = 19;
            this.label10.Text = "Birthday";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // contryLabel
            // 
            this.contryLabel.AutoSize = true;
            this.contryLabel.BackColor = System.Drawing.Color.Transparent;
            this.contryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contryLabel.ForeColor = System.Drawing.Color.Firebrick;
            this.contryLabel.Location = new System.Drawing.Point(340, 116);
            this.contryLabel.Name = "contryLabel";
            this.contryLabel.Size = new System.Drawing.Size(13, 15);
            this.contryLabel.TabIndex = 35;
            this.contryLabel.Text = "*";
            this.contryLabel.Visible = false;
            // 
            // comboBoxDays
            // 
            this.comboBoxDays.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDays.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxDays.FormattingEnabled = true;
            this.comboBoxDays.Location = new System.Drawing.Point(126, 166);
            this.comboBoxDays.Name = "comboBoxDays";
            this.comboBoxDays.Size = new System.Drawing.Size(37, 23);
            this.comboBoxDays.TabIndex = 10;
            // 
            // comboBoxMonths
            // 
            this.comboBoxMonths.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMonths.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxMonths.FormattingEnabled = true;
            this.comboBoxMonths.Location = new System.Drawing.Point(169, 166);
            this.comboBoxMonths.Name = "comboBoxMonths";
            this.comboBoxMonths.Size = new System.Drawing.Size(82, 23);
            this.comboBoxMonths.TabIndex = 11;
            this.comboBoxMonths.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // comboBoxYears
            // 
            this.comboBoxYears.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxYears.Font = new System.Drawing.Font("Comic Sans MS", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxYears.FormattingEnabled = true;
            this.comboBoxYears.Location = new System.Drawing.Point(257, 166);
            this.comboBoxYears.Name = "comboBoxYears";
            this.comboBoxYears.Size = new System.Drawing.Size(67, 23);
            this.comboBoxYears.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label11.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Teal;
            this.label11.Location = new System.Drawing.Point(13, 195);
            this.label11.MaximumSize = new System.Drawing.Size(100, 25);
            this.label11.MinimumSize = new System.Drawing.Size(100, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 23);
            this.label11.TabIndex = 20;
            this.label11.Text = "Sex";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox3
            // 
            this.groupBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox3.Controls.Add(this.button7);
            this.groupBox3.Controls.Add(this.button4);
            this.groupBox3.Controls.Add(this.comboBox9);
            this.groupBox3.Controls.Add(this.textBox3);
            this.groupBox3.Controls.Add(this.emailLabel);
            this.groupBox3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.ForeColor = System.Drawing.Color.Teal;
            this.groupBox3.Location = new System.Drawing.Point(32, 473);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(378, 83);
            this.groupBox3.TabIndex = 42;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "E-Mail";
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Century Gothic", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.Location = new System.Drawing.Point(186, 52);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(135, 23);
            this.button7.TabIndex = 42;
            this.button7.Text = "Remove";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Century Gothic", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.ForeColor = System.Drawing.Color.Black;
            this.button4.Location = new System.Drawing.Point(187, 22);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(135, 23);
            this.button4.TabIndex = 39;
            this.button4.Text = "Add";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // comboBox9
            // 
            this.comboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Location = new System.Drawing.Point(10, 51);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(171, 26);
            this.comboBox9.TabIndex = 38;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(11, 23);
            this.textBox3.MaxLength = 0;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(170, 22);
            this.textBox3.TabIndex = 33;
            // 
            // emailLabel
            // 
            this.emailLabel.AutoSize = true;
            this.emailLabel.BackColor = System.Drawing.Color.Transparent;
            this.emailLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailLabel.ForeColor = System.Drawing.Color.Firebrick;
            this.emailLabel.Location = new System.Drawing.Point(337, 24);
            this.emailLabel.Name = "emailLabel";
            this.emailLabel.Size = new System.Drawing.Size(13, 15);
            this.emailLabel.TabIndex = 34;
            this.emailLabel.Text = "*";
            this.emailLabel.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.comboBox7);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.comboBox8);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.adressLabel);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Teal;
            this.groupBox2.Location = new System.Drawing.Point(31, 383);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(378, 84);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Address";
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Century Gothic", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Location = new System.Drawing.Point(248, 52);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 41;
            this.button6.Text = "Remove";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Century Gothic", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(187, 52);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(61, 23);
            this.button3.TabIndex = 39;
            this.button3.Text = "Add Number";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // comboBox7
            // 
            this.comboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(11, 49);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(170, 26);
            this.comboBox7.TabIndex = 38;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(319, -78);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 15);
            this.label2.TabIndex = 37;
            this.label2.Text = "*";
            this.label2.Visible = false;
            // 
            // comboBox8
            // 
            this.comboBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "Home",
            "Work"});
            this.comboBox8.Location = new System.Drawing.Point(188, 22);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(132, 24);
            this.comboBox8.Sorted = true;
            this.comboBox8.TabIndex = 34;
            this.comboBox8.Text = "Home";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(11, 22);
            this.textBox2.MaxLength = 0;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(170, 22);
            this.textBox2.TabIndex = 33;
            // 
            // adressLabel
            // 
            this.adressLabel.AutoSize = true;
            this.adressLabel.BackColor = System.Drawing.Color.Transparent;
            this.adressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adressLabel.ForeColor = System.Drawing.Color.Firebrick;
            this.adressLabel.Location = new System.Drawing.Point(339, 25);
            this.adressLabel.Name = "adressLabel";
            this.adressLabel.Size = new System.Drawing.Size(13, 15);
            this.adressLabel.TabIndex = 33;
            this.adressLabel.Text = "*";
            this.adressLabel.Visible = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.comboBox6);
            this.groupBox1.Controls.Add(this.numberLabel);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.num2TextBox12);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.Teal;
            this.groupBox1.Location = new System.Drawing.Point(31, 286);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(378, 90);
            this.groupBox1.TabIndex = 40;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Number";
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Century Gothic", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Location = new System.Drawing.Point(248, 53);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 40;
            this.button5.Text = "Remove";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Century Gothic", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(188, 53);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 23);
            this.button1.TabIndex = 39;
            this.button1.Text = "Add Number";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // comboBox6
            // 
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(12, 50);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(170, 26);
            this.comboBox6.TabIndex = 38;
            // 
            // numberLabel
            // 
            this.numberLabel.AutoSize = true;
            this.numberLabel.BackColor = System.Drawing.Color.Transparent;
            this.numberLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberLabel.ForeColor = System.Drawing.Color.Firebrick;
            this.numberLabel.Location = new System.Drawing.Point(339, 23);
            this.numberLabel.Name = "numberLabel";
            this.numberLabel.Size = new System.Drawing.Size(13, 15);
            this.numberLabel.TabIndex = 37;
            this.numberLabel.Text = "*";
            this.numberLabel.Visible = false;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Home",
            "Mobile",
            "Work"});
            this.comboBox1.Location = new System.Drawing.Point(187, 22);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(136, 24);
            this.comboBox1.Sorted = true;
            this.comboBox1.TabIndex = 34;
            this.comboBox1.Text = "Home";
            // 
            // num2TextBox12
            // 
            this.num2TextBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.num2TextBox12.Location = new System.Drawing.Point(11, 22);
            this.num2TextBox12.MaxLength = 0;
            this.num2TextBox12.Name = "num2TextBox12";
            this.num2TextBox12.Size = new System.Drawing.Size(170, 22);
            this.num2TextBox12.TabIndex = 33;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Century Gothic", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(276, 563);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(133, 24);
            this.button2.TabIndex = 15;
            this.button2.Text = "Submit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(349, -30);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(129, 24);
            this.textBox1.TabIndex = 42;
            this.textBox1.Text = "Search";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.Click += new System.EventHandler(this.textBox1_Click);
            // 
            // timer2
            // 
            this.timer2.Interval = 1;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Interval = 1;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // panelView
            // 
            this.panelView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.panelView.Controls.Add(this.daysView);
            this.panelView.Controls.Add(this.monthsView);
            this.panelView.Controls.Add(this.yearsView);
            this.panelView.Controls.Add(this.sexView);
            this.panelView.Controls.Add(this.label4);
            this.panelView.Controls.Add(this.label5);
            this.panelView.Controls.Add(this.label12);
            this.panelView.Controls.Add(this.addressView);
            this.panelView.Controls.Add(this.emailView);
            this.panelView.Controls.Add(this.numberView);
            this.panelView.Controls.Add(this.label13);
            this.panelView.Controls.Add(this.label14);
            this.panelView.Controls.Add(this.label15);
            this.panelView.Controls.Add(this.zipCodeView);
            this.panelView.Controls.Add(this.label16);
            this.panelView.Controls.Add(this.nameView);
            this.panelView.Controls.Add(this.countryView);
            this.panelView.Controls.Add(this.cityView);
            this.panelView.Controls.Add(this.companyView);
            this.panelView.Controls.Add(this.label17);
            this.panelView.Controls.Add(this.label18);
            this.panelView.Controls.Add(this.label19);
            this.panelView.Controls.Add(this.backFromViewBtn);
            this.panelView.Controls.Add(this.changeViewBtn);
            this.panelView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panelView.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.panelView.Location = new System.Drawing.Point(0, 29);
            this.panelView.Name = "panelView";
            this.panelView.Size = new System.Drawing.Size(444, 625);
            this.panelView.TabIndex = 43;
            // 
            // daysView
            // 
            this.daysView.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.daysView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.daysView.Location = new System.Drawing.Point(180, 266);
            this.daysView.MaxLength = 40;
            this.daysView.Name = "daysView";
            this.daysView.ReadOnly = true;
            this.daysView.Size = new System.Drawing.Size(46, 23);
            this.daysView.TabIndex = 75;
            // 
            // monthsView
            // 
            this.monthsView.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.monthsView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monthsView.Location = new System.Drawing.Point(232, 266);
            this.monthsView.MaxLength = 40;
            this.monthsView.Name = "monthsView";
            this.monthsView.ReadOnly = true;
            this.monthsView.Size = new System.Drawing.Size(65, 23);
            this.monthsView.TabIndex = 74;
            // 
            // yearsView
            // 
            this.yearsView.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.yearsView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearsView.Location = new System.Drawing.Point(303, 266);
            this.yearsView.MaxLength = 40;
            this.yearsView.Name = "yearsView";
            this.yearsView.ReadOnly = true;
            this.yearsView.Size = new System.Drawing.Size(74, 23);
            this.yearsView.TabIndex = 73;
            // 
            // sexView
            // 
            this.sexView.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.sexView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sexView.Location = new System.Drawing.Point(180, 312);
            this.sexView.MaxLength = 40;
            this.sexView.Name = "sexView";
            this.sexView.ReadOnly = true;
            this.sexView.Size = new System.Drawing.Size(197, 23);
            this.sexView.TabIndex = 72;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label4.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Teal;
            this.label4.Location = new System.Drawing.Point(68, 459);
            this.label4.MaximumSize = new System.Drawing.Size(100, 30);
            this.label4.MinimumSize = new System.Drawing.Size(100, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 25);
            this.label4.TabIndex = 66;
            this.label4.Text = "Addresses";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label5.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Teal;
            this.label5.Location = new System.Drawing.Point(66, 410);
            this.label5.MaximumSize = new System.Drawing.Size(100, 30);
            this.label5.MinimumSize = new System.Drawing.Size(100, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(100, 25);
            this.label5.TabIndex = 65;
            this.label5.Text = "E-mails";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label12.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Teal;
            this.label12.Location = new System.Drawing.Point(66, 357);
            this.label12.MaximumSize = new System.Drawing.Size(100, 30);
            this.label12.MinimumSize = new System.Drawing.Size(100, 25);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(100, 25);
            this.label12.TabIndex = 64;
            this.label12.Text = "Numbers";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // addressView
            // 
            this.addressView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.addressView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addressView.FormattingEnabled = true;
            this.addressView.Location = new System.Drawing.Point(180, 459);
            this.addressView.Name = "addressView";
            this.addressView.Size = new System.Drawing.Size(198, 25);
            this.addressView.TabIndex = 63;
            // 
            // emailView
            // 
            this.emailView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.emailView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailView.FormattingEnabled = true;
            this.emailView.Location = new System.Drawing.Point(180, 410);
            this.emailView.Name = "emailView";
            this.emailView.Size = new System.Drawing.Size(198, 25);
            this.emailView.TabIndex = 62;
            // 
            // numberView
            // 
            this.numberView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.numberView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numberView.FormattingEnabled = true;
            this.numberView.Location = new System.Drawing.Point(180, 358);
            this.numberView.Name = "numberView";
            this.numberView.Size = new System.Drawing.Size(198, 25);
            this.numberView.TabIndex = 61;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label13.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.Teal;
            this.label13.Location = new System.Drawing.Point(68, 73);
            this.label13.MaximumSize = new System.Drawing.Size(100, 30);
            this.label13.MinimumSize = new System.Drawing.Size(100, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(100, 25);
            this.label13.TabIndex = 55;
            this.label13.Text = "City";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label14.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Teal;
            this.label14.Location = new System.Drawing.Point(67, 121);
            this.label14.MaximumSize = new System.Drawing.Size(100, 30);
            this.label14.MinimumSize = new System.Drawing.Size(100, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 25);
            this.label14.TabIndex = 56;
            this.label14.Text = "Zip Code";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label15.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Teal;
            this.label15.Location = new System.Drawing.Point(68, 167);
            this.label15.MaximumSize = new System.Drawing.Size(100, 30);
            this.label15.MinimumSize = new System.Drawing.Size(100, 25);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(100, 25);
            this.label15.TabIndex = 54;
            this.label15.Text = "Country";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // zipCodeView
            // 
            this.zipCodeView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zipCodeView.Location = new System.Drawing.Point(180, 122);
            this.zipCodeView.MaxLength = 9;
            this.zipCodeView.Name = "zipCodeView";
            this.zipCodeView.ReadOnly = true;
            this.zipCodeView.Size = new System.Drawing.Size(197, 23);
            this.zipCodeView.TabIndex = 49;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label16.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Teal;
            this.label16.Location = new System.Drawing.Point(68, 27);
            this.label16.MaximumSize = new System.Drawing.Size(100, 30);
            this.label16.MinimumSize = new System.Drawing.Size(100, 25);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(100, 25);
            this.label16.TabIndex = 51;
            this.label16.Text = "Name ";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nameView
            // 
            this.nameView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameView.Location = new System.Drawing.Point(181, 28);
            this.nameView.MaxLength = 20;
            this.nameView.Name = "nameView";
            this.nameView.ReadOnly = true;
            this.nameView.Size = new System.Drawing.Size(197, 23);
            this.nameView.TabIndex = 46;
            // 
            // countryView
            // 
            this.countryView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.countryView.Location = new System.Drawing.Point(181, 168);
            this.countryView.MaxLength = 40;
            this.countryView.Name = "countryView";
            this.countryView.ReadOnly = true;
            this.countryView.Size = new System.Drawing.Size(197, 23);
            this.countryView.TabIndex = 47;
            // 
            // cityView
            // 
            this.cityView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cityView.Location = new System.Drawing.Point(181, 75);
            this.cityView.MaxLength = 40;
            this.cityView.Name = "cityView";
            this.cityView.ReadOnly = true;
            this.cityView.Size = new System.Drawing.Size(197, 23);
            this.cityView.TabIndex = 48;
            // 
            // companyView
            // 
            this.companyView.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.companyView.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.companyView.Location = new System.Drawing.Point(180, 217);
            this.companyView.MaxLength = 40;
            this.companyView.Name = "companyView";
            this.companyView.ReadOnly = true;
            this.companyView.Size = new System.Drawing.Size(197, 23);
            this.companyView.TabIndex = 50;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label17.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Teal;
            this.label17.Location = new System.Drawing.Point(67, 215);
            this.label17.MaximumSize = new System.Drawing.Size(100, 30);
            this.label17.MinimumSize = new System.Drawing.Size(100, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 25);
            this.label17.TabIndex = 57;
            this.label17.Text = "Company";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label18.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Teal;
            this.label18.Location = new System.Drawing.Point(66, 266);
            this.label18.MaximumSize = new System.Drawing.Size(100, 30);
            this.label18.MinimumSize = new System.Drawing.Size(100, 25);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 25);
            this.label18.TabIndex = 58;
            this.label18.Text = "Birthday";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label19.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Teal;
            this.label19.Location = new System.Drawing.Point(67, 312);
            this.label19.MaximumSize = new System.Drawing.Size(100, 30);
            this.label19.MinimumSize = new System.Drawing.Size(100, 25);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(100, 25);
            this.label19.TabIndex = 59;
            this.label19.Text = "Sex";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // backFromViewBtn
            // 
            this.backFromViewBtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backFromViewBtn.ForeColor = System.Drawing.Color.Black;
            this.backFromViewBtn.Location = new System.Drawing.Point(30, 533);
            this.backFromViewBtn.Name = "backFromViewBtn";
            this.backFromViewBtn.Size = new System.Drawing.Size(133, 25);
            this.backFromViewBtn.TabIndex = 44;
            this.backFromViewBtn.Text = "Back";
            this.backFromViewBtn.UseVisualStyleBackColor = true;
            this.backFromViewBtn.Click += new System.EventHandler(this.backFromViewBtn_Click);
            // 
            // changeViewBtn
            // 
            this.changeViewBtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.changeViewBtn.ForeColor = System.Drawing.Color.Black;
            this.changeViewBtn.Location = new System.Drawing.Point(276, 533);
            this.changeViewBtn.Name = "changeViewBtn";
            this.changeViewBtn.Size = new System.Drawing.Size(133, 25);
            this.changeViewBtn.TabIndex = 15;
            this.changeViewBtn.Text = "Change";
            this.changeViewBtn.UseVisualStyleBackColor = true;
            this.changeViewBtn.Click += new System.EventHandler(this.changeViewBtn_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.panel2.Controls.Add(this.button8);
            this.panel2.Controls.Add(this.btnChangeInfoOwner);
            this.panel2.Controls.Add(this.defaultImg);
            this.panel2.Controls.Add(this.changeImageBtn);
            this.panel2.Controls.Add(this.panelImgOwner);
            this.panel2.Controls.Add(this.groupBox5);
            this.panel2.Controls.Add(this.groupBox6);
            this.panel2.Controls.Add(this.groupBox7);
            this.panel2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.ForeColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(0, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(447, 634);
            this.panel2.TabIndex = 44;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(297, 560);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(132, 26);
            this.button8.TabIndex = 6;
            this.button8.Text = "Change Info";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // btnChangeInfoOwner
            // 
            this.btnChangeInfoOwner.Location = new System.Drawing.Point(276, 599);
            this.btnChangeInfoOwner.Name = "btnChangeInfoOwner";
            this.btnChangeInfoOwner.Size = new System.Drawing.Size(153, 26);
            this.btnChangeInfoOwner.TabIndex = 5;
            this.btnChangeInfoOwner.Text = "Change Informations";
            this.btnChangeInfoOwner.UseVisualStyleBackColor = true;
            // 
            // defaultImg
            // 
            this.defaultImg.Location = new System.Drawing.Point(12, 240);
            this.defaultImg.Name = "defaultImg";
            this.defaultImg.Size = new System.Drawing.Size(132, 26);
            this.defaultImg.TabIndex = 4;
            this.defaultImg.Text = "Default Image";
            this.defaultImg.UseVisualStyleBackColor = true;
            // 
            // changeImageBtn
            // 
            this.changeImageBtn.Location = new System.Drawing.Point(12, 201);
            this.changeImageBtn.Name = "changeImageBtn";
            this.changeImageBtn.Size = new System.Drawing.Size(132, 26);
            this.changeImageBtn.TabIndex = 1;
            this.changeImageBtn.Text = "Change Image";
            this.changeImageBtn.UseVisualStyleBackColor = true;
            // 
            // panelImgOwner
            // 
            this.panelImgOwner.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelImgOwner.BackgroundImage")));
            this.panelImgOwner.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panelImgOwner.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelImgOwner.Location = new System.Drawing.Point(12, 13);
            this.panelImgOwner.Name = "panelImgOwner";
            this.panelImgOwner.Size = new System.Drawing.Size(132, 167);
            this.panelImgOwner.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.profesionOwner);
            this.groupBox5.Controls.Add(this.nameEduOwner);
            this.groupBox5.Controls.Add(this.levelOwner);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.Color.Teal;
            this.groupBox5.Location = new System.Drawing.Point(12, 286);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(417, 268);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Education";
            this.groupBox5.Visible = false;
            // 
            // profesionOwner
            // 
            this.profesionOwner.Enabled = false;
            this.profesionOwner.Location = new System.Drawing.Point(6, 230);
            this.profesionOwner.Name = "profesionOwner";
            this.profesionOwner.Size = new System.Drawing.Size(405, 23);
            this.profesionOwner.TabIndex = 15;
            // 
            // nameEduOwner
            // 
            this.nameEduOwner.Enabled = false;
            this.nameEduOwner.Location = new System.Drawing.Point(5, 146);
            this.nameEduOwner.Name = "nameEduOwner";
            this.nameEduOwner.Size = new System.Drawing.Size(406, 23);
            this.nameEduOwner.TabIndex = 14;
            // 
            // levelOwner
            // 
            this.levelOwner.Enabled = false;
            this.levelOwner.Location = new System.Drawing.Point(5, 60);
            this.levelOwner.Name = "levelOwner";
            this.levelOwner.Size = new System.Drawing.Size(406, 23);
            this.levelOwner.TabIndex = 13;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label20.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Teal;
            this.label20.Location = new System.Drawing.Point(6, 196);
            this.label20.MinimumSize = new System.Drawing.Size(132, 22);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(132, 22);
            this.label20.TabIndex = 7;
            this.label20.Text = "Profesion";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label21.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Teal;
            this.label21.Location = new System.Drawing.Point(6, 112);
            this.label21.MinimumSize = new System.Drawing.Size(132, 22);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(132, 22);
            this.label21.TabIndex = 6;
            this.label21.Text = "Name";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label22.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Teal;
            this.label22.Location = new System.Drawing.Point(6, 27);
            this.label22.MinimumSize = new System.Drawing.Size(132, 22);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(132, 22);
            this.label22.TabIndex = 5;
            this.label22.Text = "Level";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.workNumOwner);
            this.groupBox6.Controls.Add(this.addressCompanyOwner);
            this.groupBox6.Controls.Add(this.positionOwner);
            this.groupBox6.Controls.Add(this.companyOwner);
            this.groupBox6.Controls.Add(this.label23);
            this.groupBox6.Controls.Add(this.label24);
            this.groupBox6.Controls.Add(this.label25);
            this.groupBox6.Controls.Add(this.label26);
            this.groupBox6.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.ForeColor = System.Drawing.Color.Teal;
            this.groupBox6.Location = new System.Drawing.Point(12, 286);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(417, 268);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Work";
            this.groupBox6.Visible = false;
            // 
            // workNumOwner
            // 
            this.workNumOwner.Enabled = false;
            this.workNumOwner.Location = new System.Drawing.Point(141, 122);
            this.workNumOwner.Name = "workNumOwner";
            this.workNumOwner.Size = new System.Drawing.Size(270, 23);
            this.workNumOwner.TabIndex = 16;
            // 
            // addressCompanyOwner
            // 
            this.addressCompanyOwner.Enabled = false;
            this.addressCompanyOwner.Location = new System.Drawing.Point(141, 89);
            this.addressCompanyOwner.Name = "addressCompanyOwner";
            this.addressCompanyOwner.Size = new System.Drawing.Size(270, 23);
            this.addressCompanyOwner.TabIndex = 15;
            // 
            // positionOwner
            // 
            this.positionOwner.Enabled = false;
            this.positionOwner.Location = new System.Drawing.Point(141, 24);
            this.positionOwner.Name = "positionOwner";
            this.positionOwner.Size = new System.Drawing.Size(270, 23);
            this.positionOwner.TabIndex = 14;
            // 
            // companyOwner
            // 
            this.companyOwner.Enabled = false;
            this.companyOwner.Location = new System.Drawing.Point(141, 56);
            this.companyOwner.Name = "companyOwner";
            this.companyOwner.Size = new System.Drawing.Size(270, 23);
            this.companyOwner.TabIndex = 13;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label23.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Teal;
            this.label23.Location = new System.Drawing.Point(6, 122);
            this.label23.MinimumSize = new System.Drawing.Size(132, 22);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(132, 22);
            this.label23.TabIndex = 10;
            this.label23.Text = "Work number";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label24.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Teal;
            this.label24.Location = new System.Drawing.Point(6, 89);
            this.label24.MinimumSize = new System.Drawing.Size(132, 22);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(132, 22);
            this.label24.TabIndex = 9;
            this.label24.Text = "Address";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label25.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Teal;
            this.label25.Location = new System.Drawing.Point(6, 57);
            this.label25.MinimumSize = new System.Drawing.Size(130, 22);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(130, 22);
            this.label25.TabIndex = 8;
            this.label25.Text = "Company";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label26.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Teal;
            this.label26.Location = new System.Drawing.Point(5, 24);
            this.label26.MinimumSize = new System.Drawing.Size(132, 22);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(132, 22);
            this.label26.TabIndex = 7;
            this.label26.Text = "Position";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.groupBox7.Controls.Add(this.numberOwner);
            this.groupBox7.Controls.Add(this.button10);
            this.groupBox7.Controls.Add(this.button9);
            this.groupBox7.Controls.Add(this.listEmailOwner);
            this.groupBox7.Controls.Add(this.listNumberOwner);
            this.groupBox7.Controls.Add(this.yearOwner);
            this.groupBox7.Controls.Add(this.monthOwner);
            this.groupBox7.Controls.Add(this.dayOwner);
            this.groupBox7.Controls.Add(this.emailOwner);
            this.groupBox7.Controls.Add(this.addressOwner);
            this.groupBox7.Controls.Add(this.nameOwner);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.label33);
            this.groupBox7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.ForeColor = System.Drawing.Color.Teal;
            this.groupBox7.Location = new System.Drawing.Point(12, 286);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(417, 268);
            this.groupBox7.TabIndex = 2;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Personal informations";
            // 
            // numberOwner
            // 
            this.numberOwner.Location = new System.Drawing.Point(111, 98);
            this.numberOwner.Name = "numberOwner";
            this.numberOwner.Size = new System.Drawing.Size(300, 23);
            this.numberOwner.TabIndex = 20;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.ForeColor = System.Drawing.Color.Black;
            this.button10.Location = new System.Drawing.Point(275, 195);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(136, 23);
            this.button10.TabIndex = 19;
            this.button10.Text = "Delete e-mail";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.Color.Black;
            this.button9.Location = new System.Drawing.Point(275, 127);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(136, 23);
            this.button9.TabIndex = 18;
            this.button9.Text = "Delete number";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // listEmailOwner
            // 
            this.listEmailOwner.FormattingEnabled = true;
            this.listEmailOwner.Location = new System.Drawing.Point(5, 194);
            this.listEmailOwner.Name = "listEmailOwner";
            this.listEmailOwner.Size = new System.Drawing.Size(264, 24);
            this.listEmailOwner.TabIndex = 17;
            // 
            // listNumberOwner
            // 
            this.listNumberOwner.FormattingEnabled = true;
            this.listNumberOwner.Location = new System.Drawing.Point(5, 125);
            this.listNumberOwner.Name = "listNumberOwner";
            this.listNumberOwner.Size = new System.Drawing.Size(263, 24);
            this.listNumberOwner.TabIndex = 16;
            // 
            // yearOwner
            // 
            this.yearOwner.FormattingEnabled = true;
            this.yearOwner.Location = new System.Drawing.Point(288, 234);
            this.yearOwner.Name = "yearOwner";
            this.yearOwner.Size = new System.Drawing.Size(80, 24);
            this.yearOwner.TabIndex = 15;
            // 
            // monthOwner
            // 
            this.monthOwner.FormattingEnabled = true;
            this.monthOwner.Location = new System.Drawing.Point(178, 234);
            this.monthOwner.Name = "monthOwner";
            this.monthOwner.Size = new System.Drawing.Size(104, 24);
            this.monthOwner.TabIndex = 14;
            // 
            // dayOwner
            // 
            this.dayOwner.FormattingEnabled = true;
            this.dayOwner.Location = new System.Drawing.Point(111, 234);
            this.dayOwner.Name = "dayOwner";
            this.dayOwner.Size = new System.Drawing.Size(61, 24);
            this.dayOwner.TabIndex = 13;
            // 
            // emailOwner
            // 
            this.emailOwner.Enabled = false;
            this.emailOwner.Location = new System.Drawing.Point(111, 165);
            this.emailOwner.Name = "emailOwner";
            this.emailOwner.Size = new System.Drawing.Size(300, 23);
            this.emailOwner.TabIndex = 12;
            // 
            // addressOwner
            // 
            this.addressOwner.Enabled = false;
            this.addressOwner.Location = new System.Drawing.Point(111, 62);
            this.addressOwner.Name = "addressOwner";
            this.addressOwner.Size = new System.Drawing.Size(300, 23);
            this.addressOwner.TabIndex = 10;
            // 
            // nameOwner
            // 
            this.nameOwner.Enabled = false;
            this.nameOwner.Location = new System.Drawing.Point(111, 24);
            this.nameOwner.Name = "nameOwner";
            this.nameOwner.Size = new System.Drawing.Size(300, 23);
            this.nameOwner.TabIndex = 7;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label27.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Teal;
            this.label27.Location = new System.Drawing.Point(5, 235);
            this.label27.MinimumSize = new System.Drawing.Size(100, 22);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(100, 22);
            this.label27.TabIndex = 6;
            this.label27.Text = "Date of birdth";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label28.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Teal;
            this.label28.Location = new System.Drawing.Point(6, 166);
            this.label28.MinimumSize = new System.Drawing.Size(100, 22);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(100, 22);
            this.label28.TabIndex = 5;
            this.label28.Text = "E-mail";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label29.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Teal;
            this.label29.Location = new System.Drawing.Point(6, 100);
            this.label29.MinimumSize = new System.Drawing.Size(100, 22);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(100, 22);
            this.label29.TabIndex = 4;
            this.label29.Text = "Number";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label31.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Teal;
            this.label31.Location = new System.Drawing.Point(6, 62);
            this.label31.MinimumSize = new System.Drawing.Size(100, 22);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(100, 22);
            this.label31.TabIndex = 2;
            this.label31.Text = "Address";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label33.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Teal;
            this.label33.Location = new System.Drawing.Point(6, 24);
            this.label33.MinimumSize = new System.Drawing.Size(100, 22);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(100, 22);
            this.label33.TabIndex = 0;
            this.label33.Text = "Name";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // filesToolStripMenuItem
            // 
            this.filesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchToolbarToolStripMenuItem});
            this.filesToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filesToolStripMenuItem.ForeColor = System.Drawing.Color.IndianRed;
            this.filesToolStripMenuItem.Name = "filesToolStripMenuItem";
            this.filesToolStripMenuItem.Size = new System.Drawing.Size(101, 25);
            this.filesToolStripMenuItem.Text = "Phonebook";
            // 
            // searchToolbarToolStripMenuItem
            // 
            this.searchToolbarToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.onToolStripMenuItem1,
            this.offToolStripMenuItem1});
            this.searchToolbarToolStripMenuItem.Name = "searchToolbarToolStripMenuItem";
            this.searchToolbarToolStripMenuItem.Size = new System.Drawing.Size(181, 26);
            this.searchToolbarToolStripMenuItem.Text = "Search toolbar";
            // 
            // onToolStripMenuItem1
            // 
            this.onToolStripMenuItem1.Name = "onToolStripMenuItem1";
            this.onToolStripMenuItem1.Size = new System.Drawing.Size(102, 26);
            this.onToolStripMenuItem1.Text = "On";
            this.onToolStripMenuItem1.Click += new System.EventHandler(this.onToolStripMenuItem1_Click);
            // 
            // offToolStripMenuItem1
            // 
            this.offToolStripMenuItem1.Name = "offToolStripMenuItem1";
            this.offToolStripMenuItem1.Size = new System.Drawing.Size(102, 26);
            this.offToolStripMenuItem1.Text = "Off";
            this.offToolStripMenuItem1.Click += new System.EventHandler(this.offToolStripMenuItem1_Click);
            // 
            // contactsToolStripMenuItem
            // 
            this.contactsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewContactToolStripMenuItem,
            this.viewAllContactsToolStripMenuItem});
            this.contactsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contactsToolStripMenuItem.ForeColor = System.Drawing.Color.IndianRed;
            this.contactsToolStripMenuItem.Name = "contactsToolStripMenuItem";
            this.contactsToolStripMenuItem.Size = new System.Drawing.Size(82, 25);
            this.contactsToolStripMenuItem.Text = "Contacts";
            this.contactsToolStripMenuItem.Click += new System.EventHandler(this.contactsToolStripMenuItem_Click);
            // 
            // addNewContactToolStripMenuItem
            // 
            this.addNewContactToolStripMenuItem.Name = "addNewContactToolStripMenuItem";
            this.addNewContactToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D1)));
            this.addNewContactToolStripMenuItem.Size = new System.Drawing.Size(244, 26);
            this.addNewContactToolStripMenuItem.Text = "Add new contact";
            this.addNewContactToolStripMenuItem.Click += new System.EventHandler(this.addNewContactToolStripMenuItem_Click);
            // 
            // viewAllContactsToolStripMenuItem
            // 
            this.viewAllContactsToolStripMenuItem.Name = "viewAllContactsToolStripMenuItem";
            this.viewAllContactsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.D2)));
            this.viewAllContactsToolStripMenuItem.Size = new System.Drawing.Size(244, 26);
            this.viewAllContactsToolStripMenuItem.Text = "Home";
            this.viewAllContactsToolStripMenuItem.Click += new System.EventHandler(this.viewAllContactsToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Transparent;
            this.menuStrip1.BackgroundImage = global::Phonebook2.Properties.Resources.menu;
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.filesToolStripMenuItem,
            this.contactsToolStripMenuItem,
            this.profileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(612, 29);
            this.menuStrip1.TabIndex = 41;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // profileToolStripMenuItem
            // 
            this.profileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.seeYourInformationsToolStripMenuItem});
            this.profileToolStripMenuItem.ForeColor = System.Drawing.Color.IndianRed;
            this.profileToolStripMenuItem.Name = "profileToolStripMenuItem";
            this.profileToolStripMenuItem.Size = new System.Drawing.Size(67, 25);
            this.profileToolStripMenuItem.Text = "Profile";
            this.profileToolStripMenuItem.Click += new System.EventHandler(this.profileToolStripMenuItem_Click);
            // 
            // seeYourInformationsToolStripMenuItem
            // 
            this.seeYourInformationsToolStripMenuItem.Name = "seeYourInformationsToolStripMenuItem";
            this.seeYourInformationsToolStripMenuItem.Size = new System.Drawing.Size(234, 26);
            this.seeYourInformationsToolStripMenuItem.Text = "See your informations";
            this.seeYourInformationsToolStripMenuItem.Click += new System.EventHandler(this.seeYourInformationsToolStripMenuItem_Click);
            // 
            // homePanel
            // 
            this.homePanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.homePanel.Controls.Add(this.label34);
            this.homePanel.Controls.Add(this.groupBox9);
            this.homePanel.Controls.Add(this.groupBox8);
            this.homePanel.Controls.Add(this.groupBox10);
            this.homePanel.Controls.Add(this.groupBox11);
            this.homePanel.Location = new System.Drawing.Point(-3, 29);
            this.homePanel.Name = "homePanel";
            this.homePanel.Size = new System.Drawing.Size(445, 592);
            this.homePanel.TabIndex = 77;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label34.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label34.ForeColor = System.Drawing.Color.Teal;
            this.label34.Location = new System.Drawing.Point(3, 5);
            this.label34.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label34.MaximumSize = new System.Drawing.Size(440, 25);
            this.label34.MinimumSize = new System.Drawing.Size(440, 25);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(440, 25);
            this.label34.TabIndex = 0;
            this.label34.Text = "Contacts";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox9
            // 
            this.groupBox9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox9.Controls.Add(this.friendsMoreLabel);
            this.groupBox9.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox9.ForeColor = System.Drawing.Color.Teal;
            this.groupBox9.Location = new System.Drawing.Point(8, 33);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(8, 3, 3, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(433, 131);
            this.groupBox9.TabIndex = 2;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Friends";
            // 
            // friendsMoreLabel
            // 
            this.friendsMoreLabel.ActiveLinkColor = System.Drawing.Color.Red;
            this.friendsMoreLabel.AutoSize = true;
            this.friendsMoreLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.friendsMoreLabel.LinkColor = System.Drawing.Color.SpringGreen;
            this.friendsMoreLabel.Location = new System.Drawing.Point(9, 108);
            this.friendsMoreLabel.Name = "friendsMoreLabel";
            this.friendsMoreLabel.Size = new System.Drawing.Size(0, 16);
            this.friendsMoreLabel.TabIndex = 0;
            this.friendsMoreLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.friendsMoreLabel_LinkClicked);
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox8.Controls.Add(this.familyMoreLabel);
            this.groupBox8.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox8.ForeColor = System.Drawing.Color.Teal;
            this.groupBox8.Location = new System.Drawing.Point(8, 170);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(8, 3, 3, 3);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(433, 131);
            this.groupBox8.TabIndex = 1;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Family";
            // 
            // familyMoreLabel
            // 
            this.familyMoreLabel.ActiveLinkColor = System.Drawing.Color.Red;
            this.familyMoreLabel.AutoSize = true;
            this.familyMoreLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.familyMoreLabel.LinkColor = System.Drawing.Color.SpringGreen;
            this.familyMoreLabel.Location = new System.Drawing.Point(9, 106);
            this.familyMoreLabel.Name = "familyMoreLabel";
            this.familyMoreLabel.Size = new System.Drawing.Size(0, 16);
            this.familyMoreLabel.TabIndex = 1;
            this.familyMoreLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.familyMoreLabel_LinkClicked);
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox10.Controls.Add(this.colegueMoreLabel);
            this.groupBox10.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox10.ForeColor = System.Drawing.Color.Teal;
            this.groupBox10.Location = new System.Drawing.Point(8, 307);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(8, 3, 3, 3);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(433, 131);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Colegue";
            // 
            // colegueMoreLabel
            // 
            this.colegueMoreLabel.ActiveLinkColor = System.Drawing.Color.Red;
            this.colegueMoreLabel.AutoSize = true;
            this.colegueMoreLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.colegueMoreLabel.LinkColor = System.Drawing.Color.SpringGreen;
            this.colegueMoreLabel.Location = new System.Drawing.Point(9, 108);
            this.colegueMoreLabel.Name = "colegueMoreLabel";
            this.colegueMoreLabel.Size = new System.Drawing.Size(0, 16);
            this.colegueMoreLabel.TabIndex = 2;
            this.colegueMoreLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.colegueMoreLabel_LinkClicked);
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.groupBox11.Controls.Add(this.acquaintanceMoreLabel);
            this.groupBox11.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox11.ForeColor = System.Drawing.Color.Teal;
            this.groupBox11.Location = new System.Drawing.Point(8, 444);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(8, 3, 3, 3);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(433, 131);
            this.groupBox11.TabIndex = 3;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Acquaintance";
            // 
            // acquaintanceMoreLabel
            // 
            this.acquaintanceMoreLabel.ActiveLinkColor = System.Drawing.Color.Red;
            this.acquaintanceMoreLabel.AutoSize = true;
            this.acquaintanceMoreLabel.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.acquaintanceMoreLabel.LinkColor = System.Drawing.Color.SpringGreen;
            this.acquaintanceMoreLabel.Location = new System.Drawing.Point(9, 107);
            this.acquaintanceMoreLabel.Name = "acquaintanceMoreLabel";
            this.acquaintanceMoreLabel.Size = new System.Drawing.Size(0, 16);
            this.acquaintanceMoreLabel.TabIndex = 3;
            this.acquaintanceMoreLabel.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.acquaintanceMoreLabel_LinkClicked);
            // 
            // moreContactsPanel
            // 
            this.moreContactsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(50)))), ((int)(((byte)(50)))), ((int)(((byte)(50)))));
            this.moreContactsPanel.Controls.Add(this.label35);
            this.moreContactsPanel.Location = new System.Drawing.Point(0, 29);
            this.moreContactsPanel.Margin = new System.Windows.Forms.Padding(3, 3, 3, 15);
            this.moreContactsPanel.Name = "moreContactsPanel";
            this.moreContactsPanel.Size = new System.Drawing.Size(444, 592);
            this.moreContactsPanel.TabIndex = 78;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(67)))), ((int)(((byte)(78)))), ((int)(((byte)(84)))));
            this.label35.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label35.ForeColor = System.Drawing.Color.Teal;
            this.label35.Location = new System.Drawing.Point(3, 5);
            this.label35.Margin = new System.Windows.Forms.Padding(3, 5, 3, 0);
            this.label35.MaximumSize = new System.Drawing.Size(440, 25);
            this.label35.MinimumSize = new System.Drawing.Size(440, 25);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(440, 25);
            this.label35.TabIndex = 1;
            this.label35.Text = "Contacts";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // searchTextBox
            // 
            this.searchTextBox.Location = new System.Drawing.Point(303, -24);
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(117, 20);
            this.searchTextBox.TabIndex = 76;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(612, 621);
            this.Controls.Add(this.searchTextBox);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelView);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.moreContactsPanel);
            this.Controls.Add(this.homePanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Phonebook";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panelView.ResumeLayout(false);
            this.panelView.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.homePanel.ResumeLayout(false);
            this.homePanel.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.moreContactsPanel.ResumeLayout(false);
            this.moreContactsPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox CountrytextBox7;
        private System.Windows.Forms.TextBox CitytextBox5;
        private System.Windows.Forms.TextBox ZiptextBox2;
        private System.Windows.Forms.TextBox nameTextBox1;
        private System.Windows.Forms.TextBox CompanytextBox9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBoxYears;
        private System.Windows.Forms.ComboBox comboBoxMonths;
        private System.Windows.Forms.ComboBox comboBoxDays;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label companyLabel;
        private System.Windows.Forms.Label zipLabel;
        private System.Windows.Forms.Label contryLabel;
        private System.Windows.Forms.Label emailLabel;
        private System.Windows.Forms.Label adressLabel;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label cityLabel;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label numberLabel;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox num2TextBox12;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox8;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panelView;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox addressView;
        private System.Windows.Forms.ComboBox emailView;
        private System.Windows.Forms.ComboBox numberView;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox zipCodeView;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox nameView;
        private System.Windows.Forms.TextBox countryView;
        private System.Windows.Forms.TextBox cityView;
        private System.Windows.Forms.TextBox companyView;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button backFromViewBtn;
        private System.Windows.Forms.Button changeViewBtn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnChangeInfoOwner;
        private System.Windows.Forms.Button defaultImg;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox profesionOwner;
        private System.Windows.Forms.TextBox nameEduOwner;
        private System.Windows.Forms.TextBox levelOwner;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox workNumOwner;
        private System.Windows.Forms.TextBox addressCompanyOwner;
        private System.Windows.Forms.TextBox positionOwner;
        private System.Windows.Forms.TextBox companyOwner;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.ComboBox listNumberOwner;
        private System.Windows.Forms.ComboBox yearOwner;
        private System.Windows.Forms.ComboBox monthOwner;
        private System.Windows.Forms.ComboBox dayOwner;
        private System.Windows.Forms.TextBox emailOwner;
        private System.Windows.Forms.TextBox addressOwner;
        private System.Windows.Forms.TextBox nameOwner;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button changeImageBtn;
        private System.Windows.Forms.Panel panelImgOwner;
        private System.Windows.Forms.TextBox sexView;
        private System.Windows.Forms.TextBox daysView;
        private System.Windows.Forms.TextBox monthsView;
        private System.Windows.Forms.TextBox yearsView;
        private System.Windows.Forms.ToolStripMenuItem filesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolbarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem onToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem offToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem contactsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewContactToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewAllContactsToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label categoryLabel;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.FlowLayoutPanel homePanel;
        private System.Windows.Forms.Label label34;
        public System.Windows.Forms.GroupBox groupBox9;
        public System.Windows.Forms.GroupBox groupBox8;
        public System.Windows.Forms.GroupBox groupBox10;
        public System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.LinkLabel friendsMoreLabel;
        private System.Windows.Forms.LinkLabel familyMoreLabel;
        private System.Windows.Forms.LinkLabel colegueMoreLabel;
        private System.Windows.Forms.LinkLabel acquaintanceMoreLabel;
        private System.Windows.Forms.FlowLayoutPanel moreContactsPanel;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox searchTextBox;
        private System.Windows.Forms.ToolStripMenuItem profileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seeYourInformationsToolStripMenuItem;
        private System.Windows.Forms.TextBox numberOwner;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.ComboBox listEmailOwner;
    }
}

