﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phonebook2
{
    public class Address
    {
        private String address;
        private AddressType type;

        public Address()
        {
        }

        public Address(string address, AddressType type = AddressType.Home)
        {
            setAddress(address);
            setAddressType(type);
        }

        public string getAddress()
        {
            return this.address;
        }
        
        public AddressType getAddressType()
        {
            return this.type;
        }

        public void setAddress(string value)
        {
            this.address = value;
        }

        public void setAddressType(AddressType value)
        {
            this.type = value;
        }

        public override string ToString()
        {
            return String.Format("{0} - {1}", address, type.ToString());
        }
    }

    public enum AddressType
    {
        Home,
        Work
    }
}
