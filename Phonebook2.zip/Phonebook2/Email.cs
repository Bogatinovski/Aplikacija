﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phonebook2
{
    public class Email
    {
        private string emailAdress;

        public Email(string email="")
        {
                setEmailAdress(email);
        }

        public string getEmailAdress()
        {
            return emailAdress;
        }

        private void setEmailAdress(string value)
        {
            if (isValidEmail(value))
                emailAdress = value.Trim();
            else
                throw new EmailException("Invalid email format");
        }

        private bool isValidEmail(string email)
        {
            if (email == "" || String.IsNullOrWhiteSpace(email))
                return true;
            if (email.Trim().Contains(" "))
                return false;
            string[] pre = email.Split('@');
           
            if (pre.Length != 2)
                return false;

            int i = 0;
            while (i != pre[0].Length-1)
            {
                if (isSpecialChar(pre[0][i]))
                {
                    int j = i;
                    bool left = false, right = false;
                    while (j != 0)
                    {
                        if (pre[0][j] == '"')
                        {
                            left = true;
                            break;
                        }
                        j--;
                    }
                    j = i;
                    while (j != pre[0].Length - 1)
                    {
                        if (pre[0][j] == '"')
                        {
                            right = true;
                            break;
                        }
                        j++;
                    }

                    if (!left || !right)
                        return false;
                }
                i++;
            }

            string[] domain = pre[1].Split('.');
            if (domain.Length < 2)
                return false;

            foreach (string s in domain)
                if (s.Length < 1)
                    return false;

            for (int k = 0; k < domain.Length; k++)
                for(int l = 0; l < domain[k].Length; l++)
                    if(isSpecialChar(domain[k][l]))
                        return false;

            return true;
        }

        private bool isSpecialChar(char value)
        {
            if (value == 32 || value == 34  || value == 40 || value == 41 || value ==44 || value >57 && value < 61 || value ==62
                || value == 64 || value > 90 && value < 94)
                return true;
            return false;
        }

        public override string ToString()
        {
            return emailAdress;
        }
    }

    class EmailException : Exception
    {
        public EmailException()
            : base()
        {
        }

        public EmailException(string message)
            : base(message)
        {

        }
    }
}
