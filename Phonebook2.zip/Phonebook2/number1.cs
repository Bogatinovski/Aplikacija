﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Phonebook2
{
    class number1
    {
         private string number;

        public number1(string number)
        {
            setNumber(number);
        }
        public number1()
        {

        }


        public string getNumber()
        {
            return number;
        }

        public void setNumber(string value)
        {
            number = value;
        }


        public override string ToString()
        {
            return String.Format("{0}", number);
        }

    }

}
