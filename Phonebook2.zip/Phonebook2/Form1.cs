﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Threading;
using System.Reflection;
using System.Xml;

namespace Phonebook2
{
    public partial class Form1 : Form
    {
        int selectedDay;
        bool changeInfo = false;
        Contact activeContact = null;
        const string fileExtension = ".cnt";
        const string ownerFile = "owner" + fileExtension;
        const string imageFile = "ownerImage" + fileExtension;

        List<Number> numbers;
        List<number1> numbersOwner;
        List<number1> workNumsOwner;
        List<Email> emails;
        List<Email> emailsOwner;
        List<Address> addresses;
        List<ContactPanel> friendContacts;
        List<ContactPanel> familyContacts;
        List<ContactPanel> acquantainceContacts;
        List<ContactPanel> colegueContacts;
        List<Contact> allContacts;
       

        enum Months
        {
            January = 1, February, March, April, May, June, July, August, September, October, November, December
        }

        public Form1()
        {
            InitializeComponent();
            numbers = new List<Number>();
            numbersOwner = new List<number1>();
            workNumsOwner = new List<number1>();
            emails = new List<Email>();
            emailsOwner = new List<Email>();
            addresses = new List<Address>();
            allContacts = new List<Contact>();
        
            friendContacts = new List<ContactPanel>();
            familyContacts = new List<ContactPanel>();
            acquantainceContacts = new List<ContactPanel>();
            colegueContacts = new List<ContactPanel>();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            InitializeYearsComboBox(comboBoxYears);
            InitializeMonthsComboBox(comboBoxMonths);
            InitializeDaysComboBox(comboBoxDays,comboBoxMonths,comboBoxYears);
            comboBox2.SelectedIndex = 3;
            comboBox5.SelectedIndex = 1;
            
            CreateFolders();
            LoadContacts();

            PanelOff(ref panel1);
            PanelOff(ref panel2);
            PanelOff(ref panelView);
            PanelOn(ref homePanel);

            InitializeOwnerPanel();
            InitializeContactPanels();
        }


        private void InitializeContactPanels()
        {
            string[] files = Directory.GetFiles("Contacts\\Friend\\");

            foreach (string file in files)
            {
                Contact contact = new Contact();
                contact.LoadContactFromFile(file);
                ContactPanel panel = new ContactPanel(contact, this, Point.Empty, friendsPanel);
                allContacts.Add(contact);
                friendContacts.Add(panel);
            }

            files = Directory.GetFiles("Contacts\\Family\\");
            foreach (string file in files)
            {
                Contact contact = new Contact();
                contact.LoadContactFromFile(file);
                ContactPanel panel = new ContactPanel(contact, this, Point.Empty, familyPanel);
                allContacts.Add(contact);
                familyContacts.Add(panel);
            }

            files = Directory.GetFiles("Contacts\\Colegue\\");
            foreach (string file in files)
            {
                Contact contact = new Contact();
                contact.LoadContactFromFile(file);
                ContactPanel panel = new ContactPanel(contact, this, Point.Empty, coleguePanel);
                allContacts.Add(contact);
                colegueContacts.Add(panel);
            }

            files = Directory.GetFiles("Contacts\\Acquaintance\\");
            foreach (string file in files)
            {
                Contact contact = new Contact();
                contact.LoadContactFromFile(file);
                ContactPanel panel = new ContactPanel(contact, this, Point.Empty, acquaintancePanel);
                allContacts.Add(contact);
                acquantainceContacts.Add(panel);
            }
        }

        private void InitializeOwnerPanel()
        {
            listNumberOwner.Items.Clear();
            listEmailOwner.Items.Clear();
            listWorkNumOwner.Items.Clear();

            XmlDocument document = new XmlDocument();
            document.Load(ownerFile);
            nameOwner.Text = document.SelectSingleNode("Owner/PersonalInformation/Name").Attributes["Value"].Value;
            addressOwner.Text = document.SelectSingleNode("Owner/PersonalInformation/Address").Attributes["Value"].Value;
            foreach (XmlNode node in document.SelectNodes("Owner/PersonalInformation/Numbers/Number"))
                listNumberOwner.Items.Add(new number1(node.Attributes["Value"].Value));
            foreach (XmlNode node in document.SelectNodes("Owner/PersonalInformation/Emails/Email"))
                listEmailOwner.Items.Add(new Email(node.Attributes["Value"].Value));
            dayOwner.SelectedValue = document.SelectSingleNode("Owner/PersonalInformation/Birthday").Attributes["Day"].Value;
            monthOwner.SelectedValue = document.SelectSingleNode("Owner/PersonalInformation/Birthday").Attributes["Month"].Value;
            yearOwner.SelectedValue = document.SelectSingleNode("Owner/PersonalInformation/Birthday").Attributes["Year"].Value;
            levelOwner.Text = document.SelectSingleNode("Owner/WorkAndEducation/Level").Attributes["Value"].Value;
            positionOwner.Text = document.SelectSingleNode("Owner/WorkAndEducation/Position").Attributes["Value"].Value;
            companyOwner.Text = document.SelectSingleNode("Owner/WorkAndEducation/Company").Attributes["Value"].Value;
            addressCompanyOwner.Text = document.SelectSingleNode("Owner/WorkAndEducation/Address").Attributes["Value"].Value;
            foreach (XmlNode node in document.SelectNodes("Owner/WorkAndEducation/Numbers/Number"))
                listWorkNumOwner.Items.Add(new number1(node.Attributes["Value"].Value));

            if(listNumberOwner.Items.Count>0)
               listNumberOwner.SelectedIndex = listNumberOwner.Items.Count - 1;
            if(listEmailOwner.Items.Count > 0)
               listEmailOwner.SelectedIndex = listNumberOwner.Items.Count - 1;
            if(listWorkNumOwner.Items.Count > 0)
              listWorkNumOwner.SelectedIndex = listWorkNumOwner.Items.Count - 1;

            document.Load(imageFile);
            string imageValue = document.SelectSingleNode("OwnerImage/Image").Attributes["Value"].Value;
            if (imageValue.Equals("Default"))
                panelImgOwner.BackgroundImage = Properties.Resources.imgdefault;
            else panelImgOwner.BackgroundImage = Image.FromFile(imageValue);
        }

        private void ResetControlChildren(Control control)
        {
            foreach (Control c in control.Controls)
                if ( !(c is LinkLabel) && (c is Panel || c is FlowLayoutPanel || c is Label || c is PictureBox))
                    control.Controls.Remove(c);
        }

        private void LoadContacts()
        {
            List<ContactPanel> contactsPanels = new List<ContactPanel>();
           
            bool showMore = false;
            int yOffset = 40;
            int xOffset = 3;
            ResetControlChildren(groupBox8);
            ResetControlChildren(groupBox9);
            ResetControlChildren(groupBox10);
            ResetControlChildren(groupBox11);

            //// Friends
            if (Directory.GetFiles("Contacts\\Friend\\").Length > 0)
            {
                groupBox9.Visible = true;
                string[] files = Directory.GetFiles("Contacts\\Friend\\");
                showMore = files.Length > 2;
                Contact c = new Contact();
                c.LoadContactFromFile(files[0]);
                ContactPanel panel = new ContactPanel(c, this, new Point(groupBox9.Location.X-xOffset, yOffset), groupBox9);
                contactsPanels.Add(panel);

                
                if (files.Length > 1)
                {
                    c = new Contact();
                    c.LoadContactFromFile(files[1]);
                    panel = new ContactPanel(c, this, new Point(groupBox9.Location.X + ContactPanel.panelWidth, yOffset), groupBox9);
                    contactsPanels.Add(panel);
                }

                if (files.Length > 2)
                    friendsMoreLabel.Text = String.Format("Show {0} more friend contacts >>", files.Length-2);
               
            }
            else groupBox9.Visible = false;


            //// Family
            if (Directory.GetFiles("Contacts\\Family").Length > 0)
            {
                groupBox8.Visible = true;
                string[] files = Directory.GetFiles("Contacts\\Family\\");
                showMore = files.Length > 2;
                Contact c = new Contact();
                c.LoadContactFromFile(files[0]);
                ContactPanel panel = new ContactPanel(c, this, new Point(groupBox8.Location.X - xOffset, yOffset), groupBox8);
                contactsPanels.Add(panel);

                if (files.Length > 1)
                {
                    c = new Contact();
                    c.LoadContactFromFile(files[1]);
                    panel = new ContactPanel(c, this, new Point(groupBox8.Location.X + ContactPanel.panelWidth, yOffset), groupBox8);
                    contactsPanels.Add(panel);
                }
                if (files.Length > 2)
                    familyMoreLabel.Text = String.Format("Show {0} more family contacts >>", files.Length - 2);
            }
            else groupBox8.Visible = false;

            /// Colegue
            if (Directory.GetFiles("Contacts\\Colegue").Length > 0)
            {
                groupBox10.Visible = true;
                string[] files = Directory.GetFiles("Contacts\\Colegue\\");
                showMore = files.Length > 2;
                Contact c = new Contact();
                c.LoadContactFromFile(files[0]);
                ContactPanel panel = new ContactPanel(c, this, new Point(groupBox10.Location.X - xOffset, yOffset), groupBox10);
                contactsPanels.Add(panel);
                if (showMore)
                    panel.DisableContactPanel();
                else panel.EnableContactPanel();
                if (files.Length > 1)
                {
                    c = new Contact();
                    c.LoadContactFromFile(files[1]);
                    panel = new ContactPanel(c, this, new Point(groupBox10.Location.X + ContactPanel.panelWidth, yOffset), groupBox10);
                    contactsPanels.Add(panel);
                }
                if (files.Length > 2)
                    colegueMoreLabel.Text = String.Format("Show {0} more colegue contacts >>", files.Length - 2);

            }
            else groupBox10.Visible = false;

            /// Acquaintance
            if (Directory.GetFiles("Contacts\\Acquaintance").Length > 0)
            {
                groupBox11.Visible = true;
                string[] files = Directory.GetFiles("Contacts\\Acquaintance\\");
                showMore = files.Length > 2;
                Contact c = new Contact();
                c.LoadContactFromFile(files[0]);
                ContactPanel panel = new ContactPanel(c, this, new Point(groupBox11.Location.X - xOffset, yOffset), groupBox11);
                contactsPanels.Add(panel);

                if (files.Length > 1)
                {
                    c = new Contact();
                    c.LoadContactFromFile(files[1]);
                    panel = new ContactPanel(c, this, new Point(groupBox11.Location.X + ContactPanel.panelWidth, yOffset), groupBox11);
                    contactsPanels.Add(panel);
                    if (showMore)
                        panel.DisableContactPanel();
                    else panel.EnableContactPanel();
                }
                if (files.Length > 2)
                    acquaintanceMoreLabel.Text = String.Format("Show {0} more acquaintance contacts >>", files.Length - 2);
            }
            else groupBox11.Visible = false;

            foreach (ContactPanel p in contactsPanels)
                p.DisableContactPanel();
        }

        private void InitializeYearsComboBox(ComboBox years)
        {
            years.Items.Clear();
            for (int i = 1900; i <= DateTime.Today.Year; i++)
                years.Items.Add(i);
            years.SelectedItem = DateTime.Today.Year;
        }
        private void ResetYears()
        {
            comboBoxYears.Items.Clear();
            for (int i = 1900; i <= DateTime.Today.Year; i++)
                comboBoxYears.Items.Add(i);
        }
 
        private void ResetDays(ComboBox days, ComboBox months, ComboBox years)
        {
            days.Items.Clear();
            for (int i = 1; i <= DateTime.DaysInMonth(int.Parse(years.SelectedItem.ToString()), months.SelectedIndex+1); i++)
                days.Items.Add(i);
            days.SelectedIndex = selectedDay;
        }
        private void InitializeMonthsComboBox(ComboBox months)
        {
            months.Items.Clear();
            for (int i = 1; i <= 12; i++)
                months.Items.Add((Months)(i));
            months.SelectedItem = (Months)DateTime.Now.Month;
        }
        private void InitializeDaysComboBox(ComboBox days, ComboBox months, ComboBox years)
        {
            days.Items.Clear();
            for (int i = 1; i <= DateTime.DaysInMonth(int.Parse(years.SelectedItem.ToString()), months.SelectedIndex+1); i++ )
                days.Items.Add(i);
            days.SelectedItem = DateTime.Now.Day;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                selectedDay = comboBoxDays.SelectedIndex;
                comboBoxDays.Items.Clear();
                ResetDays(comboBoxDays, comboBoxMonths, comboBoxYears);
            }
            catch { }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Contact contact = null;
            if(changeInfo)
                contact = ChangeContact();
            else
                contact = CreateContact();

            if (contact != null)
            {
                LoadContacts();
                AddContactToPanel(contact);
                EnableHomePanel();
                changeInfo = false;
            }
        }

        private void AddContactToPanel(Contact c)
        {
            ContactPanel panel = null;
            switch(c.getCategory())
            {
                
                case Category.Acquaintance:
                    panel = new ContactPanel(c, this, Point.Empty, acquaintancePanel);
                    acquantainceContacts.Add(panel);
                    break;
               
                case Category.Colegue:
                    panel = new ContactPanel(c, this, Point.Empty, coleguePanel);
                    colegueContacts.Add(panel);
                    break;

                case Category.Friend:
                    panel = new ContactPanel(c, this, Point.Empty, friendsPanel);
                    friendContacts.Add(panel);
                    break;

                case Category.Family:
                    panel = new ContactPanel(c, this, Point.Empty, familyPanel);
                    familyContacts.Add(panel);
                    break;
            }
        }

        private void CreateFolders()
        {
            foreach(Category folder in Enum.GetValues(typeof(Category)))
            {
                if (!Directory.Exists("Contacts\\" + folder.ToString()))
                    Directory.CreateDirectory("Contacts\\" + folder.ToString() + "\\");

            }
        }

        private Contact ChangeContact()
        {
            if (String.IsNullOrEmpty(nameTextBox1.Text.Trim()))
            {
                label3.Text = "Enter Name";
                nameLabel.Visible = true;
                return null;
            }

            string photoPath;
            DateTime birthday;

            resetLabels();

            photoPath = (comboBox5.SelectedIndex == 0 ? "Photos\\" + Contact.MALE_PHOTO : "Photos\\" + Contact.FEMALE_PHOTO);


            int y = comboBoxYears.SelectedIndex + 1900;
            int m = comboBoxMonths.SelectedIndex + 1;
            int d = comboBoxDays.SelectedIndex + 1;
            try
            {
                birthday = new DateTime(y, m, d);
            }
            catch
            {
                MessageBox.Show("Select date");
                return null;
            }

            string city = CitytextBox5.Text;
            string country = CountrytextBox7.Text;
            string name = nameTextBox1.Text;


            string company = CompanytextBox9.Text;
            string zipCode = ZiptextBox2.Text;
            Category category = (Category)comboBox2.SelectedIndex;

            Contact newContact = null;
            try
            {
                Sex sex = (Sex)comboBox5.SelectedIndex;

                newContact = new Contact(comboBox6.Items.Cast<Number>().ToList<Number>(),
                comboBox9.Items.Cast<Email>().ToList<Email>(), birthday,
                comboBox7.Items.Cast<Address>().ToList<Address>(), city, country, company, name, zipCode, sex, category);
            }
            catch (InvalidZipCodeException ex)
            {
                zipLabel.Visible = true;
                label3.Text = ex.Message;
                return null;
            }

            if (!Directory.Exists("Contacts"))
                Directory.CreateDirectory("Contacts");
            if (!Directory.Exists("Photos"))
                Directory.CreateDirectory("Photos");


            string filename = activeContact.fileName;
            File.Delete(filename);

            FlowLayoutPanel p;
            switch(activeContact.getCategory())
            {
                case Category.Acquaintance:
                    p = acquaintancePanel;
                    foreach(ContactPanel cp in acquantainceContacts)
                        if(cp.getContact().Equals(activeContact))
                        {
                            cp.Dispose();
                            acquantainceContacts.Remove(cp);
                            break;
                        }
                    break;
                case Category.Friend:
                    p = friendsPanel;
                    foreach (ContactPanel cp in friendContacts)
                        if (cp.getContact().Equals(activeContact))
                        {
                            cp.Dispose();
                            friendContacts.Remove(cp);
                            break;
                        }
                    break;
                case Category.Family:
                    p = familyPanel;
                    foreach (ContactPanel cp in familyContacts)
                        if (cp.getContact().Equals(activeContact))
                        {
                            cp.Dispose();
                            familyContacts.Remove(cp);
                            break;
                        }
                    break;
                case Category.Colegue:
                    p = coleguePanel;
                    foreach (ContactPanel cp in colegueContacts)
                        if (cp.getContact().Equals(activeContact))
                        {
                            cp.Dispose();
                            colegueContacts.Remove(cp);
                            break;
                        }
                    break;
            }


            newContact.fileName = filename;
          
            label3.Text = "";
            resetLabels();
            newContact.SaveContactToFile();
            return newContact;
        }
        private void EnablePanel2()
        {
            PanelOn(ref panel2);
            PanelOff(ref homePanel);
            PanelOff(ref panel1);
            PanelOff(ref panelView);
          //  PanelOff(ref moreContactsPanel);
        }
        private void EnablePanel1()
        {
            PanelOn(ref panel1);
            PanelOff(ref homePanel);
            PanelOff(ref panel2);
            PanelOff(ref panelView);
         //   PanelOff(ref moreContactsPanel);
        }

        private void EnableHomePanel()
        {
            PanelOff(ref panel1);
            PanelOff(ref panel2);
            PanelOff(ref panelView);
            PanelOn(ref homePanel);
          //  PanelOff(ref moreContactsPanel);
        }

        private void EnableMoreContactsPanel()
        {
         //   PanelOn(ref moreContactsPanel);
            PanelOff(ref panel1);
            PanelOff(ref panel2);
            PanelOff(ref panelView);
            PanelOff(ref homePanel);
        }
        
        private void addNewContactToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnablePanel1();
            changeInfo = false;
        }

        private void viewAllContactsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnableHomePanel();
            changeInfo = false;
        }

        private void changeInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel1.BringToFront();
        }
       
        private void onToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            timer3.Enabled = true;
        }

        private void offToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            timer2.Enabled = true;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (searchTextBox.Location.Y > -30)
                searchTextBox.Location = new Point(searchTextBox.Location.X, searchTextBox.Location.Y - 1);
            else
            {
                searchTextBox.Location = new Point(searchTextBox.Location.X, -30);
                timer2.Enabled = false;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (searchTextBox.Location.Y < 1)
                searchTextBox.Location = new Point(searchTextBox.Location.X, searchTextBox.Location.Y + 1);
            else
            {
                searchTextBox.Location = new Point(searchTextBox.Location.X, 1);
                timer3.Enabled = false;
            }
        }

        #region Methods

        public void ShowContactInfo(Contact c)
        {
            nameView.Text = c.getName();
            cityView.Text = c.getCity();
            zipCodeView.Text = c.getZipCode();
            countryView.Text = c.getCountry();
            companyView.Text = c.getCompany();
            sexView.Text = c.getSex().ToString();

            numberView.Items.Clear();
            numberView.Items.AddRange(c.getNumber().ToArray());
            if (numberView.Items.Count > 0)
                numberView.SelectedIndex = 0;

            emailView.Items.Clear();
            emailView.Items.AddRange(c.getEmail().ToArray());
            if (emailView.Items.Count > 0)
                emailView.SelectedIndex = 0;

            addressView.Items.Clear();
            addressView.Items.AddRange(c.getAdress().ToArray());
            if (addressView.Items.Count > 0)
                addressView.SelectedIndex = 0;

            yearsView.Text = (c.getBirthday().Year).ToString();

            monthsView.Text = (c.getBirthday().Month).ToString();

            daysView.Text = (c.getBirthday().Day).ToString();
            activeContact = c;
            PanelOn(ref panelView);
        }

        private void resetLabels()
        {
            nameLabel.Visible = false;
            numberLabel.Visible = false;
            adressLabel.Visible = false;
            emailLabel.Visible = false;
            contryLabel.Visible = false;
            cityLabel.Visible = false;
            zipLabel.Visible = false;
            companyLabel.Visible = false;
        }

        private Contact CreateContact()
        {
            if(String.IsNullOrEmpty(nameTextBox1.Text.Trim()))
            {
                label3.Text = "Enter Name";
                nameLabel.Visible = true;
                return null;
            }
            
            string photoPath;
            DateTime birthday;

            resetLabels();

            photoPath = (comboBox5.SelectedIndex == 0 ? "Photos\\" + Contact.MALE_PHOTO : "Photos\\" + Contact.FEMALE_PHOTO);


            int y = comboBoxYears.SelectedIndex + 1900;
            int m = comboBoxMonths.SelectedIndex + 1;
            int d = comboBoxDays.SelectedIndex + 1;
            try
            {
                birthday = new DateTime(y, m, d);
            }
            catch
            {
                MessageBox.Show("Select date");
                return null;
            }

            string city = CitytextBox5.Text;
            string country = CountrytextBox7.Text;
            string name = nameTextBox1.Text;


            string company = CompanytextBox9.Text;
            string zipCode = ZiptextBox2.Text;

            Category category = (Category)comboBox2.SelectedIndex;

            Contact newContact = null;
            try
            {
                Sex sex = (Sex)comboBox5.SelectedIndex;

                newContact = new Contact(comboBox6.Items.Cast<Number>().ToList<Number>(),
                comboBox9.Items.Cast<Email>().ToList<Email>(), birthday,
                comboBox7.Items.Cast<Address>().ToList<Address>(), city, country, company, name, zipCode, sex, category);
            }
            catch (InvalidZipCodeException ex)
            {
                zipLabel.Visible = true;
                label3.Text = ex.Message;
                return null;
            }

            if (!Directory.Exists("Contacts"))
                Directory.CreateDirectory("Contacts");
            if (!Directory.Exists("Photos"))
                Directory.CreateDirectory("Photos");


            string filename = "Contacts\\" + category.ToString()+"\\" + newContact.getName() + fileExtension;
            while (File.Exists(filename))
            {
                Random rand = new Random();
                filename = "Contacts\\" + category.ToString() + "\\" + newContact.getName() + rand.Next(0, 1000).ToString() + fileExtension;
            }

            newContact.fileName = filename;
            label3.Text = "";
            resetLabels();
            newContact.SaveContactToFile();
            
            return newContact;
        }

        void PanelOff(ref Panel p)
        {
            p.Visible = false;
            p.Enabled = false;
            p.SendToBack();
        }
        void PanelOn(ref Panel p)
        {
            p.Enabled = true;
            p.Visible = true;
            p.BringToFront();
        }
        void PanelOff(ref FlowLayoutPanel p)
        {
            p.Visible = false;
            p.Enabled = false;
            p.SendToBack();
        }
        void PanelOn(ref FlowLayoutPanel p)
        {
            p.Enabled = true;
            p.Visible = true;
            p.BringToFront();
        }

        #endregion  


        private void button1_Click(object sender, EventArgs e)
        {
            Number number = null;

            if (String.IsNullOrEmpty(num2TextBox12.Text.Trim()))
            {
                numberLabel.Visible = true;
                label3.Text = "Empty number field";
                return;
            }

            number = new Number(num2TextBox12.Text, (NumberType)comboBox1.SelectedIndex);
            comboBox6.Items.Add(number);
            numbers.Add(number);
            comboBox6.SelectedIndex = comboBox6.Items.Count - 1;

            label3.Text = "";
            numberLabel.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Address address = null;

            if (String.IsNullOrEmpty(textBox2.Text.Trim()))
            {
                adressLabel.Visible = true;
                adressLabel.Text = "Empty address field";
                return;
            }

            address = new Address(textBox2.Text, (AddressType)comboBox8.SelectedIndex);
            comboBox7.Items.Add(address);
            addresses.Add(address);
            comboBox7.SelectedIndex = comboBox7.Items.Count - 1;

            label3.Text = "";
            adressLabel.Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Email email = null;
            try
            {
                email = new Email(textBox3.Text);
                emailLabel.Visible = false;
                label3.Text = "";
                comboBox9.Items.Add(email);
                emails.Add(email);
                comboBox9.SelectedIndex = comboBox9.Items.Count - 1;
            }
            catch(EmailException ex)
            {
                emailLabel.Visible = true;
                label3.Text = ex.Message;
            }
        }

        private void changeViewBtn_Click(object sender, EventArgs e)
        {
            EnablePanel1();
            changeInfo = true;
            FillContactForm();
        }

        private void FillContactForm()
        {
            nameTextBox1.Text = activeContact.getName();
            CitytextBox5.Text = activeContact.getCity();
            ZiptextBox2.Text = activeContact.getZipCode();
            CountrytextBox7.Text = activeContact.getCountry();
            CompanytextBox9.Text = activeContact.getCompany();
            InitializeYearsComboBox(comboBoxYears);
            InitializeMonthsComboBox(comboBoxMonths);
            InitializeDaysComboBox(comboBoxDays, comboBoxMonths, comboBoxYears);
            comboBoxYears.SelectedIndex = activeContact.getBirthday().Year - 1900;
            comboBoxMonths.SelectedIndex = activeContact.getBirthday().Month - 1;
            comboBoxDays.SelectedIndex = activeContact.getBirthday().Day-1;
            comboBox5.SelectedIndex = (int)activeContact.getSex();
            comboBox2.SelectedIndex = (int)activeContact.getCategory();

            comboBox6.Items.Clear();
            comboBox7.Items.Clear();
            comboBox9.Items.Clear();
            comboBox6.Items.AddRange(activeContact.getNumber().ToArray());
            comboBox7.Items.AddRange(activeContact.getAdress().ToArray());
            comboBox9.Items.AddRange(activeContact.getEmail().ToArray());
            if (comboBox6.Items.Count > 0)
                comboBox6.SelectedIndex = 0;
            if (comboBox7.Items.Count > 0)
                comboBox7.SelectedIndex = 0;
            if (comboBox9.Items.Count > 0)
                comboBox9.SelectedIndex = 0;

            numbers = activeContact.getNumber();
            emails = activeContact.getEmail();
            addresses = activeContact.getAdress();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if(comboBox6.SelectedItem!=null)
            {
                numbers.Remove((Number)comboBox6.SelectedItem);
                comboBox6.Items.Clear();
                comboBox6.Items.AddRange(numbers.ToArray());
                if (comboBox6.Items.Count > 0)
                    comboBox6.SelectedIndex = 0;
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (comboBox7.SelectedItem != null)
            {
                addresses.Remove((Address)comboBox7.SelectedItem);
                comboBox7.Items.Clear();
                comboBox7.Items.AddRange(addresses.ToArray());
                if (comboBox7.Items.Count > 0)
                    comboBox7.SelectedIndex = 0;
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (comboBox9.SelectedItem != null)
            {
                emails.Remove((Email)comboBox9.SelectedItem);
                comboBox9.Items.Clear();
                comboBox9.Items.AddRange(emails.ToArray());
                if (comboBox9.Items.Count > 0)
                    comboBox9.SelectedIndex = 0;
            }
        }


        private void backFromViewBtn_Click(object sender, EventArgs e)
        {
            PanelOff(ref panelView);
            changeInfo = false;
        }

        private void friendsMoreLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            friendsPanel.BringToFront();
            //ShowAllContacts(Category.Friend);
        }
    

        private void familyMoreLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            familyPanel.BringToFront();
           // ShowAllContacts(Category.Family);
        }

        private void colegueMoreLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            coleguePanel.BringToFront();
          //  ShowAllContacts(Category.Colegue);
        }

        private void acquaintanceMoreLabel_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            acquaintancePanel.BringToFront();
          //  ShowAllContacts(Category.Acquaintance);
        }

        private void profileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void contactsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void seeYourInformationsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EnablePanel2();
            changeInfo = false;
        }
       
        int i = 0;
        private void button8_Click(object sender, EventArgs e)
        {
            if (i == 0)
            {
                button8.Text="Save changes";
                nameOwner.ReadOnly = false;
                emailOwner.ReadOnly = false;
                numberOwner.ReadOnly = false;
                addressOwner.ReadOnly = false;
                levelOwner.ReadOnly = false;
                positionOwner.ReadOnly = false;
                companyOwner.ReadOnly = false;
                addressCompanyOwner.ReadOnly = false;
                workNumOwner.ReadOnly = false;
                i = 1;
            }
            else {
                button8.Text = "Change Info";
                nameOwner.ReadOnly = true;
                emailOwner.ReadOnly = true;
                numberOwner.ReadOnly = true;
                addressOwner.ReadOnly = true;
                levelOwner.ReadOnly = true;
                positionOwner.ReadOnly = true;
                companyOwner.ReadOnly = true;
                addressCompanyOwner.ReadOnly = true;
                workNumOwner.ReadOnly = true;

                

                number1 number = null;
                if (String.IsNullOrEmpty(numberOwner.Text.Trim()))
                { i = 0; }
                else
                {
                    number = new number1(numberOwner.Text);
                    listNumberOwner.Items.Add(number);
                    numbersOwner.Add(number);
                    listNumberOwner.SelectedIndex = listNumberOwner.Items.Count - 1;
                    numberOwner.Text = "";
                    i = 0;
                }

                if (String.IsNullOrEmpty(workNumOwner.Text.Trim()))
                { i = 0; }
                else
                {
                    number = new number1(workNumOwner.Text);
                    listWorkNumOwner.Items.Add(number);
                    workNumsOwner.Add(number);
                    listWorkNumOwner.SelectedIndex = listWorkNumOwner.Items.Count - 1;
                    workNumOwner.Text = "";
                    i = 0;
                }

                Email email = null;
                try
                {
                    if(!String.IsNullOrEmpty(emailOwner.Text.Trim()))
                    {
                    email = new Email(emailOwner.Text.Trim());
                    listEmailOwner.Items.Add(email);
                    emailsOwner.Add(email);
                    listEmailOwner.SelectedIndex = listEmailOwner.Items.Count - 1;
                    emailOwner.Text = "";
                    i = 0;
                    }
                }
                catch (EmailException ex)
                {
                    MessageBox.Show(ex.Message);
                    emailOwner.Text = "";
                }

                SaveOwnerInfo();
            }

        }

        private void SaveOwnerInfo()
        {
            XmlDocument document = new XmlDocument();

            XmlElement root = document.CreateElement("Owner");
            document.AppendChild(root);
            XmlElement personal = document.CreateElement("PersonalInformation");
            root.AppendChild(personal);
            XmlAttribute value;
            
            /// Name
            XmlElement name = document.CreateElement("Name");
            value = document.CreateAttribute("Value");
            value.Value = nameOwner.Text.Trim();
            name.Attributes.Append(value);
            personal.AppendChild(name);

            /// Address
            XmlElement address = document.CreateElement("Address");
            value = document.CreateAttribute("Value");
            value.Value = addressOwner.Text.Trim();
            address.Attributes.Append(value);
            personal.AppendChild(address);
            
            /// Numbers
            XmlElement numbers = document.CreateElement("Numbers");
            personal.AppendChild(numbers);
            foreach(number1 o in listNumberOwner.Items)
            {
                if (String.IsNullOrEmpty(o.ToString().Trim()))
                    continue;
                XmlElement number = document.CreateElement("Number");
                value = document.CreateAttribute("Value");
                value.Value = o.ToString().Trim();
                number.Attributes.Append(value);
                numbers.AppendChild(number);
            }

            /// Emails
            XmlElement emails = document.CreateElement("Emails");
            personal.AppendChild(emails);
            foreach (Email o in listEmailOwner.Items)
            {
                if (String.IsNullOrEmpty(o.ToString().Trim()))
                    continue;
                XmlElement email = document.CreateElement("Email");
                value = document.CreateAttribute("Value");
                value.Value = o.ToString().Trim();
                email.Attributes.Append(value);
                emails.AppendChild(email);
            }
            

            //// Birthday
            XmlAttribute attribute;
            XmlElement birthdayElement = document.CreateElement("Birthday");
            attribute = document.CreateAttribute("Day");
            if(dayOwner.SelectedValue!=null)
                 attribute.Value = dayOwner.SelectedValue.ToString();
            birthdayElement.Attributes.Append(attribute);
            attribute = document.CreateAttribute("Month");
            if (monthOwner.SelectedValue != null)
                attribute.Value = monthOwner.SelectedValue.ToString();
            birthdayElement.Attributes.Append(attribute);
            attribute = document.CreateAttribute("Year");
            if (yearOwner.SelectedValue != null)
                attribute.Value = yearOwner.SelectedValue.ToString();
            birthdayElement.Attributes.Append(attribute);
            personal.AppendChild(birthdayElement);

            XmlElement work = document.CreateElement("WorkAndEducation");
            root.AppendChild(work);

            /// Level of Education
            XmlElement level = document.CreateElement("Level");
            value = document.CreateAttribute("Value");
            value.Value = levelOwner.Text.Trim();
            level.Attributes.Append(value);
            work.AppendChild(level);

            /// Position
            XmlElement position = document.CreateElement("Position");
            value = document.CreateAttribute("Value");
            value.Value = positionOwner.Text.Trim();
            position.Attributes.Append(value);
            work.AppendChild(position);

            //// Company
            XmlElement companyElement = document.CreateElement("Company");
            attribute = document.CreateAttribute("Value");
            attribute.Value = companyOwner.Text.Trim();
            companyElement.Attributes.Append(attribute);
            work.AppendChild(companyElement);

            //// Address Company
            XmlElement addressCompany = document.CreateElement("Address");
            attribute = document.CreateAttribute("Value");
            attribute.Value = addressCompanyOwner.Text.Trim();
            addressCompany.Attributes.Append(attribute);
            work.AppendChild(addressCompany);

            /// Work Numbers
            XmlElement workNumbers = document.CreateElement("Numbers");
            work.AppendChild(workNumbers);
            foreach (number1 o in listWorkNumOwner.Items)
            {
                if (String.IsNullOrEmpty(o.ToString().Trim()))
                    continue;
                XmlElement number = document.CreateElement("Number");
                value = document.CreateAttribute("Value");
                value.Value = o.ToString().Trim();
                number.Attributes.Append(value);
                workNumbers.AppendChild(number);
            }

            try
            {
                document.Save(ownerFile);
            }
            catch(UnauthorizedAccessException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void defaultImg_Click(object sender, EventArgs e)
        {
            panelImgOwner.BackgroundImage = Properties.Resources.imgdefault;
            SaveOwnerImageToFile("Default");
        }

        private void changeImageBtn_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog2.ShowDialog();
            if (result == DialogResult.OK)
            {
                try
                {
                    panelImgOwner.BackgroundImage = Image.FromFile(openFileDialog2.FileName);
                    SaveOwnerImageToFile(openFileDialog2.FileName);
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            
        }

        private void SaveOwnerImageToFile(string file)
        {
            XmlDocument document = new XmlDocument();
            XmlElement root = document.CreateElement("OwnerImage");
            document.AppendChild(root);
            XmlElement image = document.CreateElement("Image");
            XmlAttribute attribute = document.CreateAttribute("Value");
            attribute.Value = file;
            image.Attributes.Append(attribute);
            root.AppendChild(image);
            document.Save(imageFile);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (listNumberOwner.SelectedItem != null)
            {
                numbersOwner.Remove((number1)listNumberOwner.SelectedItem);
                listNumberOwner.Items.Clear();
                listNumberOwner.Items.AddRange(numbersOwner.ToArray());
                if (listNumberOwner.Items.Count > 0)
                    listNumberOwner.SelectedIndex = 0;

                SaveOwnerInfo();
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (listEmailOwner.SelectedItem != null)
            {
                emailsOwner.Remove((Email)listEmailOwner.SelectedItem);
                listEmailOwner.Items.Clear();
                listEmailOwner.Items.AddRange(emailsOwner.ToArray());
                if (listEmailOwner.Items.Count > 0)
                    listEmailOwner.SelectedIndex = 0;

                SaveOwnerInfo();
            }
           

        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (listWorkNumOwner.SelectedItem != null)
            {
               workNumsOwner.Remove((number1)listWorkNumOwner.SelectedItem);
                listWorkNumOwner.Items.Clear();
                listWorkNumOwner.Items.AddRange(workNumsOwner.ToArray());
                if (listWorkNumOwner.Items.Count > 0)
                    listWorkNumOwner.SelectedIndex = 0;

                SaveOwnerInfo();
            }
        }

        private void searchTextBox_TextChanged(object sender, EventArgs e)
        {
            String text = searchTextBox.Text;
            ResetSearchPanel();
            if (text.Length < 2)
            {
                EnableHomePanel();
                return;
            }

            searchPanel.BringToFront();
            
            List<ContactPanel> allPanels = new List<ContactPanel>();
            allPanels.AddRange(friendContacts);
            allPanels.AddRange(familyContacts);
            allPanels.AddRange(acquantainceContacts);
            allPanels.AddRange(colegueContacts);

            foreach(ContactPanel p in allPanels)
            {
                Contact c = p.getContact();
                if (c.ToString().ToLower().Contains(text.ToLower()))
                    searchPanelContacts.Add(new ContactPanel(c, this, Point.Empty, searchPanel));
            }
           
        }

        private List<ContactPanel> searchPanelContacts = new List<ContactPanel>();

        private void ResetSearchPanel()
        {
            foreach (ContactPanel c in searchPanelContacts)
                c.Dispose();
            searchPanelContacts = new List<ContactPanel>(0);
        }

        private void onToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timer3.Start();
        }

        private void offToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            timer2.Start();
        }

    }
}
